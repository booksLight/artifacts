$(function() {
	$("#feedback-tab").click(function() {
		$("#feedback-form").toggle("slide");
	});

	$("#feedback-form form").on('submit', function(event) {
		var $form = $(this);
		var search = {}
		
		search["body"] = $("#body").val();
		search["email"] = $("#email").val();
		
		$.ajax({
			contentType : "application/json",
			type: $form.attr('method'),
			url: $form.attr('action'),
			data: JSON.stringify(search),
			success: function(res) {
				 $("#ack").html(res);  
				 
				$("#feedback-form").toggle("slide").find("textarea").val('');
			},
	        error: function(jqXHR, textStatus, errorThrown) {
	            alert(jqXHR.status + ' ' + jqXHR.responseText);
	        }
		
		
		});
			
		event.preventDefault();
	});
	
	
});

