$(document).ready(function() {
	
	$("#invLedger").on("click", function() {		
		$("#mainDiv").load("/admin/order");
	});

	$("#invCatalogue").on("click", function() {	
		$("#mainDiv").load("/admin/productInventory");
	});

	$("#invPortfolio").on("click", function() {
		$("#mainDiv").load("/admin/customers");		
	});
	var toDo = "false";
	 var table = $('#ordRepo').DataTable({
		 "lengthMenu": [[5, 10, 15, -1], [5, 10, 15, "All"]],	
		 "sAjaxSource": "/admin/repo",
			"sAjaxDataProp": "",
			"order": [[ 0, "asc" ]],
			"aoColumns": [
				  { "mData": "customerOrderId", 
					  render : function(data) {
						  return data		                 
		                } 				 
				  },
		          { "mData": "customerName" },
				  { "mData": "productName" },
				  { "mData": "orderedQty", "class": "text-center"},
				  { "mData": "orderedAmt", "class": "text-center"},
				  { "mData": "stamped" ,
				  "render": function (mData) {
				        var date = new Date(mData);
				        var month = date.getMonth() + 1;
				        return date.getDate() + "/" + (month.length > 1 ? month : "0" + month) + "/" + date.getFullYear()
				       /* + " " +date.getHours()+ ":" +date.getMinutes()+ ":" +date.getSeconds()*/
				        ;
				    }
				  },
				  { "mData": "status" },
				  { "mData": "confirmed",
					  render : function(data) {
						  toDo = data;
						  if(data==false){
							  return '<button type="button" id="ack_button" value="CONF" style="font-size:12pt;color:white;background-color:green;border:2px solid #336600;padding:3px; border-radius:25px;">Approve</button>';
						  }else{
							  return "Confirmed";		                 
		                } 	
					  }
				  },
				  { "mData": "shipped",
					  render : function(data) {
						   if(data==false){	
							   if(toDo==true ){
								  return  '<button type="button" id="ship_button" value="SHIP" style="font-size:12pt;color:white;background-color:green;border:2px solid #336600;padding:3px; border-radius:25px;">Approve</button>';   
							  }else{
								  return "NA";
							  }
						  }else{
							  return "Shipped";
						  }
					  }
				  }
			],
			 retrieve: true,
			 paging: true
	 });
	
	
	 
	 $("#ship_button").on("click", function() {		
			alert("ship_button clicked");
		});
	 
	 $('#ordRepo tbody').on('click', 'td', function () {	
		 	// Retrieving clicked Cell Value
		   
		 /*var dtv = table.cell( this ).data();   		  
		    var row_num = parseInt($(this).parent().index())+1;
		    var dtrv =$(this).closest("tr").find("td:eq(0)").text();
		    console.log( 'The Value of  clicked Cell= '+dtv+'\'s and Key='+dtrv ); 	*/	  
		   /* $("#mainDiv").load("/cart/order/book/"+dtv); */
		   /* $.post("/cart/order/book/"+dtv );*/
		    return;
		} );

	
	 
	 $('#ordRepo tbody').on('click', 'td button', function () {		
		 	// Retrieving clicked button Value
		 	var btv =$(this).attr("value");  		  
		    
		 	// Identifying event row number
		 	var row_num = parseInt($(this).parent().index())+1;
		 	
		 	// Identifying OrderID for the Event   
		 	var dtrv =$(this).closest("tr").find("td:eq(0)").text();
		 	
			console.log( 'The '+ btv + ' button clicked for the Key (OrderId) = '+dtrv ); 
			if(btv=='CONF'){
				$.post("/admin/action/conf/"+dtrv );
			}
			if(btv=='SHIP'){
				$.post("/admin/action/ship/"+dtrv );
			}
			
			$("#mainDiv").load("/admin/order");
		    return;
		} );
	 
});


function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
