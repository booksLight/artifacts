$(document).ready(function() {		
		
	$("#cusoffer").on('submit', function(event) {	
	        $.ajax({
             url: '/customer/offer/coupon',
             type: 'post',
             data:$(this).serialize(),
             success: function(res) {
            	 $("#ackc").html(res); 
             },
		        error: function(jqXHR, textStatus, errorThrown) {
		            alert(jqXHR.status + ' ' + jqXHR.responseText);
		        }
         });       
        event.preventDefault();
    });
});
