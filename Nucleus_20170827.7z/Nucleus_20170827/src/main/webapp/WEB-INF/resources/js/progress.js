jQuery(document).ready(function() {
	
  var back = jQuery(".prev");
  var next = jQuery(".next");
  var steps = jQuery(".step");
  var isDisp = $("#isDispatched").val();
  var isShip = $("#isShipped").val();
  var isDliverred = $("#isDelivered").val();
  
  if (isDisp=='true') {	
	  $("#disp").addClass('current');     
    }
  
  if (isShip=='true') {	 
	  $("#ship").addClass('current');     
	  $("#disp").removeClass('current').addClass('done');  
    }
  
  if (isDliverred=='true') {	
	  $("#dliv").addClass('current');    
	  $("#ship").removeClass('current').addClass('done');    
	  $("#disp").removeClass('current').addClass('done');  
    }

  
  next.bind("click", function() {
//    jQuery.each(steps, function(i) {
//      if (!jQuery(steps[i]).hasClass('current') && !jQuery(steps[i]).hasClass('done')) {
//        jQuery(steps[i]).addClass('current');
//        jQuery(steps[i - 1]).removeClass('current').addClass('done');
//        return false;
//      }
//    })
  });
  back.bind("click", function() {
  /*  jQuery.each(steps, function(i) {
      if (jQuery(steps[i]).hasClass('done') && jQuery(steps[i + 1]).hasClass('current')) {
        jQuery(steps[i + 1]).removeClass('current');
        jQuery(steps[i]).removeClass('done').addClass('current');
        return false;
      }
    })*/
  });

})