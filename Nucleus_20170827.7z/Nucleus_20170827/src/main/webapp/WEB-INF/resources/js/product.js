$(document).ready(function() {
	
	var table = $('#prodInvTbl').DataTable({
		 "lengthMenu": [[5, 10, 15, -1], [5, 10, 15, "All"]],	
		 "sAjaxSource": "/product/products/0",
			"sAjaxDataProp": "",
			"order": [[ 0, "asc" ]],
			"aoColumns": [
				  { "mData": "id",				  
                      render: function (data) {
                          return '<center><img src="/images/'+data+'.png" style="width: 50%"></center>';
                      }
                  },
		          { "mData": "productName" },
				  { "mData": "productCategory" },
				  { "mData": "productCondition"},
				  { "mData": "productPrice"},
				  { "mData": "productManufacture"},
				  { "mData":  "id",
					  render: function (data) {
                          return '<center><a href="/admin/product/editProduct/'+data+'"> <span class="glyphicon glyphicon-pencil"></span></a> &nbsp;&nbsp; <a href="/admin/product/delete/'+data+'"> <span class="glyphicon glyphicon-remove"></span></a></center>';
                      }
				  }
			],
			 retrieve: true,
			 paging: true
	 });

	
});


