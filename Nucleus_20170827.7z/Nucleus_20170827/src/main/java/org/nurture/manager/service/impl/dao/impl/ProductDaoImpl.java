package org.nurture.manager.service.impl.dao.impl;

import java.util.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.nurture.manager.entity.Categeory;
import org.nurture.manager.entity.Product;
import org.nurture.manager.service.impl.dao.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.hibernate.*;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;


/**
 * Created by Rakesh on 04.04.2017.
 */
@Repository
@Transactional
public class ProductDaoImpl implements ProductDao {
	
	private static final Logger logger = LoggerFactory.getLogger(ProductDaoImpl.class);

    @Autowired
    private SessionFactory sessionFactory;

    public Integer addProduct(Product product) {
        Session session = sessionFactory.getCurrentSession();
        Integer prodductId = (Integer) session.save(product);
        session.flush();
        return prodductId;
    }

    public void updateProduct(Product product) {
    	logger.debug("\n*****  TO UPDATE PRODUCT ="+product.toString());
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(product);
        logger.debug("\n *****  Product updated successfully");
        session.flush();
    }

    public void deleteProduct(Product product) {
        Session session = sessionFactory.getCurrentSession();
        session.delete(product);
        session.flush();
    }

  
    
    public Product getProductById(final int productKey) {
    	daoImplLog(this.getClass(), "getProductById("+productKey +")", "START");
        Session session = sessionFactory.openSession();       
        return (Product) sessionFactory.openSession()
				.createCriteria(Product.class)
				.add(Restrictions.eq("productId", productKey))	
				.uniqueResult();
    }

	public List<Product> getProducts(Integer offset, Integer maxResults, String categeoryKey , String lookUp ) {
		return (List<Product>) sessionFactory.openSession()
				.createCriteria(Product.class)
				.add(Restrictions.eq("productCategory", categeoryKey.toUpperCase()))
				.add(Restrictions.eq("productManufacture",lookUp.toUpperCase()))
				.setFirstResult(offset)
				.setMaxResults(maxResults)
				.list();
	}
	
	public List<Product> getProductsPage(Integer offset, Integer maxResults, String lookUp) {
		logger.info("\n*****DAO Finding   getProductsPage ("+offset+", "+maxResults+", "+ lookUp +")");
		return getProducts(offset,maxResults,lookUp);		
	}
	
	public List<Product> getProductsPage(Integer offset, Integer maxResults, String categeoryKey, String lookUp ) {
		logger.info("\n*****DAO Finding   getProductsPage ("+offset+", "+maxResults+", "+ categeoryKey +", "+lookUp+")");
		return getProducts(offset,maxResults,categeoryKey,lookUp);		
	}
	
	private List<Product> getProducts(Integer offset, Integer maxResults, String lookUp) {
		logger.info("\n*****DAO Finding   getProducts ("+offset+", "+maxResults+", "+ lookUp+")");
		return sessionFactory.openSession()
				.createCriteria(Product.class)
				.add(Restrictions.like("productCategory", lookUp))			
				.setFirstResult(offset)
				.setMaxResults(maxResults)
				.list();
	}
	

	public Long countProducts(String categeoryKey){		
		//openSession
		return (Long)sessionFactory.getCurrentSession() 
				.createCriteria(Product.class)
				.add(Restrictions.eq("productCategory",categeoryKey))
				.setProjection(Projections.rowCount())
				.uniqueResult();
	}
	
	
	public Long countProducts(String categeoryKey, String lookUp ){
		//openSession
		return (Long)sessionFactory.getCurrentSession()   
				.createCriteria(Product.class) 
				.add(Restrictions.like("productCategory",categeoryKey.toUpperCase()))
				.add(Restrictions.like("productManufacture",lookUp))
				.setProjection(Projections.rowCount())
				.uniqueResult();
	}

	public Set<Categeory> getCategeories() {
		Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from Categeory");
        List<Categeory> categories = query.list();
        logger.debug(" ******* Categories =");
		for(Categeory cat : categories){
			logger.debug(" ******* Categories ="+cat.getCatId()+"  // "+cat.getCatName()+"  // "+cat.hashCode());
		}
		return new HashSet<Categeory>(categories);
	}

	public List<Product> getProducts(Integer offset, Integer maxResults) {
		logger.info("\n DAO :  getAllProduts( "+offset+", "+maxResults+") ");
		//openSession
		return sessionFactory.getCurrentSession()
				.createCriteria(Product.class)
				/*.add(Restrictions.ne("productManufacture","BPS"))
				.add(Restrictions.ne("productManufacture","DPS"))*/
				.setFirstResult(offset)
				.setMaxResults(maxResults)
				.list();
	}

	 private void daoImplLog(Class<? extends ProductDaoImpl> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}
}
