package org.nurture.manager.service.impl.dao;

import java.util.List;

import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.springframework.stereotype.*;


public interface CartItemDao {
    void addCartItem(CartItem cartItem);

    void removeCartItem(CartItem cartItem);

    void removeCartItemById(Integer cartItemId);
    
    void removeAllCartItems(Cart cart);

    CartItem getCartItemByProductId(int productId);
}
