package org.nurture.manager.service.impl.dao;

import java.util.List;

import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.springframework.stereotype.*;


import java.io.IOException;

@Repository
public interface CartDao {

    Cart getCartById(int cartId);

    Cart validate(int cartId) throws IOException;

    void update(Cart cart);

	void updateGrandTotal(Cart cart);
}
