package org.nurture.manager.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;


public class Constants {

	static Properties prop;
	static InputStream input = null;
	
	//model Info
	public static  String MODEL_TITILE;
	public static String MODEL_PRODUCTS;
	public static String MODEL_CONTACTS;
	public static String MODEL_HOME;
	public static String MODEL_REGISTER;
	public static String MODEL_LOGIN;
	public static String MODEL_LOGOUT;
	public static String MODEL_USER;
	
	// Session Attributes
		public static String SESSION_USER;
		
		
		// Privileged Attributes :
		public static String ROL_TYPE_ADM;
		public static String ROL_TYPE_CUS;
		public static String ROL_TYPE_USE;
		public static String ROL_TYPE_VIS;
		
		// Number based on alphabet orders!
		public static  Integer ADM_ID;
		public static  Integer CUST_ID;
		public static  Integer USE_ID;
		public static  Integer VIS_ID;
		
		// General Attributes
		public static  boolean TRUE;
		public static  boolean FALSE;
		public static  String  STR_NULL;
		
		// Mailing Property
		public static final String myUser = "contact.bookslight@gmail.com";
		public static final String mypwd = "nyatorbiciexteyc";

		// Uploading Static Contents Images / Icons.
		public static final String[] ALLOWED_FILE_TYPES = {"image/png", "image/jpeg", "image/jpg", "image/gif"};
		public static  Long MAX_FILE_SIZE;
		
		@Value("${nurture.contents.static.img}")
		public static  String UPLOAD_FILE_PATH;
		//public static  String UPLOAD_FILE_PATH ="/opt/apache-tomcat-8.5.12/webapps/images/";
	
	
	public Constants() {
		prop = new  Properties();
		 try{
			 input =  this.getClass().getResourceAsStream("/nurture.properties");
			 prop.load(input);
			 MODEL_TITILE = prop.getProperty("dash.bar.header.title");
			 MODEL_HOME = prop.getProperty("dash.bar.header.home");
			 MODEL_PRODUCTS = prop.getProperty("dash.bar.header.products");
			 MODEL_CONTACTS = prop.getProperty("dash.bar.header.contacts");			
			 MODEL_REGISTER = prop.getProperty("dash.bar.header.register");					 
			 MODEL_LOGIN = prop.getProperty("dash.bar.header.login");
			 MODEL_LOGOUT = prop.getProperty("dash.bar.header.logout");
			 MODEL_USER = prop.getProperty("dash.bar.header.user");
			 
			 SESSION_USER =  prop.getProperty("model.session.user");
					 
			 ROL_TYPE_ADM = prop.getProperty("model.user.roll.adm");	 
			 ROL_TYPE_CUS = prop.getProperty("model.user.roll.cus");	 
			 ROL_TYPE_USE =	prop.getProperty("model.user.roll.use");
			 ROL_TYPE_VIS = prop.getProperty("model.user.roll.vis");
					 
			 ADM_ID = Integer.valueOf(prop.getProperty("model.roll.adm"));
			 CUST_ID = Integer.valueOf(prop.getProperty("model.roll.cus"));
			 USE_ID = Integer.valueOf(prop.getProperty("model.roll.use"));
			 VIS_ID = Integer.valueOf(prop.getProperty("model.roll.vis"));
			 
			 TRUE = Boolean.valueOf(prop.getProperty("model.switch.true"));
			 FALSE = Boolean.valueOf(prop.getProperty("model.switch.false"));
			 STR_NULL = prop.getProperty("model.object.null");
			 
			 UPLOAD_FILE_PATH  = prop.getProperty("model.resource.upload.path");
			 MAX_FILE_SIZE = Long.valueOf(prop.getProperty("model.resource.max.size"));
			 
		 }catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
	}
	

	
	
}
