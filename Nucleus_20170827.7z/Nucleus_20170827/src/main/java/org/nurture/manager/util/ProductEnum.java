package org.nurture.manager.util;

public enum ProductEnum {

	GENERAL("GEN"), 
	STATIONARY("STS"), 
	SPORTANDFITNESS("SNF"), 
	ACADEMIC("ACA"), 
	NOTAPPLICABLE("NA");	
	
	private ProductEnum(String productType) {
		this.productType = productType;
	}

	private String productType;

	public String getProductType() {
		return productType;
	}

}
