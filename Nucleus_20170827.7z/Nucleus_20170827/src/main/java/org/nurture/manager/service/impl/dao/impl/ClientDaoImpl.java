package org.nurture.manager.service.impl.dao.impl;

import java.math.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.*;
import org.nurture.manager.service.impl.dao.*;
import org.nurture.manager.util.*;
import org.slf4j.*;
import org.hibernate.*;
import org.hibernate.Session;
import java.io.IOException;
@Repository
@Transactional
public class ClientDaoImpl implements ClientDao {

	private static final Logger logger = LoggerFactory.getLogger(ClientDaoImpl.class);
	
	 @Autowired
	 private SessionFactory sessionFactory;

	 
	public Iterable<Client> findAll(Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	public Page<Client> findAll(Pageable pageable) {
		daoImplLog(this.getClass(), "findAll", "START");
		final Integer PAGE_SIZE = 10;
		
		
		Session session = sessionFactory.getCurrentSession();
		Query<Product> query = session.createQuery("Product product");
		query.setFirstResult(0);
		query.setMaxResults(10);
		List<Product> productList = query.list();
		
		for(Product prod : productList){
			logger.debug("Products ="+prod.getProductId() + "\t"+prod.getProductName());
		}
		
		daoImplLog(this.getClass(), "findAll", "END");
		return null;
	}

	public <S extends Client> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	public <S extends Client> Iterable<S> save(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	public Client findOne(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean exists(Integer id) {
		// TODO Auto-generated method stub
		return false;
	}

	public Iterable<Client> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Iterable<Client> findAll(Iterable<Integer> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void delete(Integer id) {
		// TODO Auto-generated method stub

	}

	public void delete(Client entity) {
		// TODO Auto-generated method stub

	}

	public void delete(Iterable<? extends Client> entities) {
		// TODO Auto-generated method stub

	}

	public void deleteAll() {
		// TODO Auto-generated method stub

	}

	

	//Generic Logger for this class
	private void daoImplLog(Class<? extends ClientDaoImpl> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}
}
