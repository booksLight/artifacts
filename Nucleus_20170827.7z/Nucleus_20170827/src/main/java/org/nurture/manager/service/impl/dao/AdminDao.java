package org.nurture.manager.service.impl.dao;

import java.util.List;

import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;

public interface AdminDao {

	List<OrderMapper> getOrdersRowMapper();
	
	void orderedApproval(Integer orderKey);
	
	void shipmentApproval(Integer orderKey);
}
