package org.nurture.manager.service.impl.dao.impl;

import java.util.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.nurture.manager.entity.*;
import org.nurture.manager.service.impl.dao.*;
import org.slf4j.*;
import org.hibernate.*;
import org.hibernate.Session;

/**
 * Created by Rakesh on 07.05.2016.
 */
@Repository
@Transactional
public class CartItemDaoImpl implements CartItemDao{

	private static final Logger logger = LoggerFactory.getLogger(CartItemDaoImpl.class);
	
    @Autowired
    private SessionFactory sessionFactory;

    public void addCartItem(CartItem cartItem) {
    	 daoLog(this.getClass(), "addCartItem", "START-Once");   
        Session session = sessionFactory.getCurrentSession();   
        session.saveOrUpdate(cartItem);
        session.flush();
        daoLog(this.getClass(), "addCartItem", "END-Once");
    }

    public void removeCartItem(CartItem cartItem) {
    	 daoLog(this.getClass(), "removeCartItem", "START"); 
        Session session = sessionFactory.getCurrentSession();
        session.delete(cartItem);     
        session.flush();
        daoLog(this.getClass(), "removeCartItem", "END"); 
    }

    public void removeAllCartItems(Cart cart) {
    	 daoLog(this.getClass(), "removeAllCartItems", "START"); 
    	if(cart.getCartItems() != null){
    		List<CartItem> cartItems = cart.getCartItems();

        for (CartItem item : cartItems) {
            removeCartItem(item);
        }
    	}
    	 daoLog(this.getClass(), "removeAllCartItems", "END"); 
    }

    public CartItem getCartItemByProductId(int productId) {
    	 daoLog(this.getClass(), "getCartItemByProductId", "START"); 
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from CartItem where productId = ?");
        query.setInteger(0, productId);
        session.flush();
        daoLog(this.getClass(), "getCartItemByProductId", "END"); 
        return (CartItem) query.uniqueResult();
        
    }

	public void removeCartItemById(Integer cartItemId) {
		daoLog(this.getClass(), "removeCartItemById", "START"); 		
		 Session session = sessionFactory.getCurrentSession();			 
		 Query query = session.createQuery("delete CartItem where cartItemId = :cartItemId");
		 query.setParameter("cartItemId", cartItemId);		  
		 int result = query.executeUpdate();		  
		 if (result > 0) {
			 daoLog(this.getClass(), "removeCartItemById", "deleted successfully"); 			
		 }
		 daoLog(this.getClass(), "removeCartItemById", "END"); 
	}

	 private void daoLog(Class<? extends CartItemDaoImpl> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}
}
