package org.nurture.manager.service.impl.dao;

import java.util.List;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.data.repository.*;

public interface CustomerOrderDao {

    void addCustomerOrder(CustomerOrder customerOrder);
    void saveOrUpdateOrderBook(OrderBook orderBookParam);
	CustomerOrder getCustomerOrderById(Integer customerOrderId);
	List<OrderBook> getOrderedBooksByOrderId(Integer customerOrderId);
	List<CustomerOrder> getCustomerOrdersByCartId(Integer cartId);
}
