package org.nurture.manager.service.impl.dao;

import java.util.List;
import java.util.Set;

import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.data.repository.*;

import java.util.List;

public interface ProductDao {

    Product getProductById(int id);

    Integer addProduct(Product product);

    void updateProduct(Product product);

    void deleteProduct(Product product);

	List<Product> getProducts(Integer offset, Integer maxResults);
	
	List<Product> getProductsPage(Integer offset, Integer maxResults, String lookUp);
	List<Product> getProductsPage(Integer offset, Integer maxResults, String  categeoryKey, String lookUp);

	Long countProducts(String categeoryKey);
	
	Long countProducts(String  categeoryKey, String lookUp);
	
	public Set<Categeory> getCategeories();
}
