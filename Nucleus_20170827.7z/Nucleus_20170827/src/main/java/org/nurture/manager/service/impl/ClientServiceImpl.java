package org.nurture.manager.service.impl;

import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.slf4j.*;

@Service
public class ClientServiceImpl implements ClientService {

	private static final Logger logger = LoggerFactory.getLogger(ClientServiceImpl.class);
	
	 @Autowired
	 private ClientDao clientDao;
	 
	public Page<Client> getClientsByPage(Pageable pageable) {
		svcLog(this.getClass(), "getClientsByPage", "START");
		
			return clientDao.findAll(pageable);
	}

	
	
	private void svcLog(Class<? extends ClientServiceImpl> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		
	}
}
