package org.nurture.manager.service;

import org.nurture.manager.entity.*;
import java.util.List;

public interface CustomerService {

    void addCustomer(Customer customer);

    Customer getCustomerById(Integer id);

    List<Customer> getAllCustomers();

    Customer getCustomerByUsername(String username);

	Customer getCustomerByUserID(Integer userId);

	boolean updateShippingAddress(Customer customerParam);
	
	public boolean updateAvailedCoupon(int couponID, String flagValue, int cartKey);
	
	public boolean updateCustomerAvailedCoupon( int couponID, int custmerID);
	
}
