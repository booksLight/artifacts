package org.nurture.manager.service;

import java.util.List;

import org.nurture.manager.entity.*;


public interface CustomerOrderService {
	
    void addCustomerOrder(CustomerOrder customerOrder);
    
    void saveOrUpdateOrderBook(OrderBook orderBookParam);    

    double getCustomerOrderGrandTotal(int cartId);

    CustomerOrder getCustomerOrderById(Integer customerOrderId);
    
	List<OrderBook> getOrderedBooksByOrderId(Integer customerOrderId);

	List<CustomerOrder> getCustomerOrdersByCartId(Integer cartId);
	

}
