package org.nurture.manager.service.impl.dao;

import java.util.List;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.data.repository.*;

public interface ClientDao extends PagingAndSortingRepository<Client,Integer>{

}
