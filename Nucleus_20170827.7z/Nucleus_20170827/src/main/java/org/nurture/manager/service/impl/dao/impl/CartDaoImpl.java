package org.nurture.manager.service.impl.dao.impl;

import java.math.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.*;
import org.nurture.manager.service.impl.dao.*;
import org.nurture.manager.util.*;
import org.slf4j.*;
import org.hibernate.*;
import org.hibernate.Session;
import java.io.IOException;

/**
 * Created by Rakesh Sharma on 22.02.2017.
 */
@Repository
@Transactional
public class CartDaoImpl implements CartDao {
	
	private static final Logger logger = LoggerFactory.getLogger(CartDaoImpl.class);
	
    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private CustomerOrderService customerOrderService;

    public Cart getCartById(int cartId) {
    	daoLog(this.getClass(), "getCartById("+cartId+")", "START");
        Session session = sessionFactory.openSession();
         Cart cart =(Cart) session.get(Cart.class, cartId);
         if(cart!=null){
        	 System.out.println("\n ITEMS in Cart ==="+cart.getCartItems().size());
        	 for(CartItem item :cart.getCartItems()){
        		 System.out.println("\n CART ITEMS ==="+item.toString());
        	 }
        	 daoLog(this.getClass(), "getCartById("+cartId+")", "END");
        	 return cart;
         }
         daoLog(this.getClass(), "getCartById("+cartId+")", "END with Null");
         return null;
    }

    public Cart validate(int cartId) throws IOException {
    	logger.debug("\n ******\t this is requestParameters.cartId = "+cartId);
       /* Cart cart = getCartById(cartId);
        if (cart == null || cart.getCartItems().size() == 0) {
              throw new IOException(cartId + "");
        }

        update(cart);
        return cart;*/
    	
    	return null;
    }

    public void update(Cart cart) {
        int cartId = cart.getCartId();
        double grandTotal = customerOrderService.getCustomerOrderGrandTotal(cartId);
        cart.setGrandTotal(grandTotal);
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(cart);
    }

	public void updateGrandTotal(Cart cartParam) {
		daoLog(this.getClass(), "updateGrandTotal", "START");
		 Session session = sessionFactory.getCurrentSession();
		 
		String hqlUpdateQuery= "update Cart set grandTotal=:cartTotal where cartId=:newCartId";
			 Query query1 = session.createSQLQuery(hqlUpdateQuery);
			 		query1.setParameter("cartTotal", cartParam.getGrandTotal());
			 		query1.setParameter("newCartId",cartParam.getCartId());
		int rowCount = query1.executeUpdate();
		logger.debug("Grand Total updated.... Cart Rows affected: " + rowCount);
		daoLog(this.getClass(), "updateGrandTotal", "END");
	}
	
	
	
	 private void daoLog(Class<? extends CartDaoImpl> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}
}
