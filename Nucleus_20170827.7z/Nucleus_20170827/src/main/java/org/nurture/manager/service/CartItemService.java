package org.nurture.manager.service;

import org.nurture.manager.entity.*;

public interface CartItemService {
    void addCartItem(CartItem cartItem);

    void removeCartItem(CartItem cartItem);
    
    void removeCartItemById(Integer cartItemId);

    void removeAllCartItems(Cart cart);

    CartItem getCartItemByProductId(int productId);
}
