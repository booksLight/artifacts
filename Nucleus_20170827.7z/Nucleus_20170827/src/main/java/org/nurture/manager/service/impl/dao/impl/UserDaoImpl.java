package org.nurture.manager.service.impl.dao.impl;

import java.math.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.*;
import org.nurture.manager.service.impl.dao.*;
import org.nurture.manager.util.*;
import org.slf4j.*;
import org.hibernate.*;
import org.hibernate.Session;
import java.io.IOException;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	private static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	  @Autowired
	  private SessionFactory sessionFactory;
	  
	public void addUser(ModelUser user) {
		if(user != null){
		 Session session = sessionFactory.getCurrentSession();
		 session.saveOrUpdate(user);
		 udaoImplLog(this.getClass(), "addUser", "The "+user.getUserEmail() +"Successfully registered!");
		}else{
			udaoImplLog(this.getClass(), "addUser", "The user is null..");
		}
	}

	public ModelUser getUserById(Integer id) {
		 Session session = sessionFactory.getCurrentSession();
		return session.get(ModelUser.class, id);
	}

	public List<ModelUser> getAllUsers() {
		 Session session = sessionFactory.getCurrentSession();
		 Query query = session.createQuery("from Users");
	        List<ModelUser> userList = query.list();
	        return userList;
	}

	public ModelUser getUserByName(String username) {
		Session session = sessionFactory.getCurrentSession();
		 Query query = session.createQuery("from Users where username = ?");
	        query.setString(0, username);
	        if(query.uniqueResult() != null){
	        return (ModelUser) query.uniqueResult() ;
	        }else{
	        	return null;
	        }
	}

	
	public ModelUser getUserByMobile(String mobile) {
		logger.debug("\n *************** getUserByMobile() :"+mobile);
		Session session = sessionFactory.getCurrentSession();
		 Query query = session.createQuery("from Users where mobile = ?");
	        query.setString(0, mobile);
	        if(query.uniqueResult() != null){
	        return (ModelUser) query.uniqueResult() ;
	        }else{
	        	return null;
	        }
	}
	
	
	
	
	

public void updateUserName(ModelUser userParam) {
	udaoImplLog(this.getClass(), "updateUserName", " START");
		if(userParam != null ){
			
			Session session = sessionFactory.getCurrentSession();
			String hqlUpdateQuery= "update users set username=:userNameParm, rolId=:rolIdParm where userId=:userIdParam";
			
			Query query1 = session.createSQLQuery(hqlUpdateQuery);
	 		query1.setParameter("userNameParm",userParam.getUsername().toString());
        	query1.setParameter("rolIdParm",userParam.getRolId());
        	query1.setParameter("userIdParam",userParam.getUserId());	
        	int rowCount = query1.executeUpdate();
       
        	logger.debug("**** User has been updated with Name and Roll; Rows affected: " + rowCount);
		}
		
		udaoImplLog(this.getClass(), "updateUserName", " END");
		
	}

	


//Generic Logger for this class
private void udaoImplLog(Class<? extends UserDaoImpl> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
	}
}
