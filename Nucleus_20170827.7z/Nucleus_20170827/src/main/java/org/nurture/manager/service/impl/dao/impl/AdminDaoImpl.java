package org.nurture.manager.service.impl.dao.impl;

import java.math.*;
import java.sql.*;
import java.net.*;
import java.util.*;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.*;
import org.nurture.manager.service.impl.dao.*;
import org.nurture.manager.util.*;
import org.slf4j.*;
import org.hibernate.*;
import org.hibernate.Session;



@Repository
@Transactional
public class AdminDaoImpl implements AdminDao {

private static final Logger logger = LoggerFactory.getLogger(AdminDaoImpl.class);
	
    @Autowired
    private SessionFactory sessionFactory;
    
	public List<OrderMapper> getOrdersRowMapper() {
		daoAdminLog(this.getClass(), "getOrdersRowMapper", "START ");
		 List<OrderMapper> oms = null;
		 OrderMapper om;
		String ORDER_ROW_MAPPER_HQL = "SELECT c.customerName,  p.productName, sum(ob.quantity), sum(ob.totalPrice), co.stamped, co.customerOrderId, co.status, co.cartId, co.isConfirmed, co.isShipped"
				+ "	FROM Customer c "
				+ " JOIN CustomerOrder co ON c.cartId = co.cartId AND c.customerId = co.customerId "
				+ " JOIN OrderBook ob ON c.cartId = ob.cartId AND ob.cartId = c.cartId AND ob.orderId = co.customerOrderId"
				+ " JOIN Product p ON p.productId = ob.productId "
				+ " GROUP BY co.customerOrderId";
		
		
        Session session = sessionFactory.getCurrentSession();
       try{
        Query query = session.createNativeQuery(ORDER_ROW_MAPPER_HQL);
        
        List<Object[]> list = query.list();
        oms = new ArrayList<OrderMapper>();
       int counter=1;
        for(Object[] arr : list){
        	om = new OrderMapper();
        	om.setId(counter);
        	om.setCustomerName(arr[0].toString());
        	om.setProductName(arr[1].toString());
        	om.setOrderedQty(((BigDecimal)arr[2]).intValue());
        	om.setOrderedAmt((Double)arr[3]);
			om.setStamped((Timestamp)arr[4]);
			om.setCustomerOrderId((Integer)arr[5]);
			om.setStatus(arr[6].toString());
			om.setConfirmed((arr[8].toString() != null ? (arr[8].toString().equalsIgnoreCase("1") ? true : false) : false));
			om.setShipped((arr[9].toString() != null ? (arr[9].toString().equalsIgnoreCase("1") ? true : false) : false));
			oms.add(om);
			logger.debug("\n\t Result =  :"+om.toString());
			 counter++;
		}
        
       }catch(Exception e){
    	   logger.debug("\n\t ORDER_ROW_MAPPER_HQL : Error ::"+e.getMessage());
       }
        daoAdminLog(this.getClass(), "getOrdersRowMapper", "END ");
		return oms;
	}

	public void orderedApproval(Integer orderKey) {
		daoAdminLog(this.getClass(), "orderedApproval", "START "); 
		Session session = sessionFactory.getCurrentSession();
		 try{
			String hqlUpdateQuery= "update customerorder set isConfirmed=:digSignature, status=:eventMsg, stamped=:doStamped  where customerOrderId=:refKey";
				 Query query1 = session.createSQLQuery(hqlUpdateQuery);
				 		query1.setParameter("digSignature", 1);
				 		query1.setParameter("eventMsg", "Confirmed");
				 		query1.setParameter("doStamped",CallenderUtil.convertDateJavaToSqlTimestamp(new Date()));
				 		query1.setParameter("refKey",orderKey);
				 		int rowCount = query1.executeUpdate();
			logger.debug("The Ordered (" + orderKey+ ") got approved by Admin.");
		 }catch(Exception e){
			 logger.error("Ordered Product Approval Update Error "+e.getMessage() );
		 }
			
		daoAdminLog(this.getClass(), "orderedApproval", "END "); 
	}

	public void shipmentApproval(Integer orderKey) {
		daoAdminLog(this.getClass(), "shipmentApproval", "START "); 
		Session session = sessionFactory.getCurrentSession();
		 try{
			String hqlUpdateQuery= "update customerorder set isShipped=:digSignature, status=:eventMsg, stamped=:doStamped where customerOrderId=:refKey";
				 Query query1 = session.createSQLQuery(hqlUpdateQuery);
				 		query1.setParameter("digSignature", 1);
				 		query1.setParameter("eventMsg", "Shipped");
				 		query1.setParameter("doStamped",CallenderUtil.convertDateJavaToSqlTimestamp(new Date()));
				 		query1.setParameter("refKey",orderKey);
			int rowCount = query1.executeUpdate();
			logger.debug("The Shipment (" + orderKey+ ") got approved by Admin.");
		 }catch(Exception e){
			 
			 logger.error("Shipment Approval Update Error "+e.getMessage() );
		 }			
		daoAdminLog(this.getClass(), "shipmentApproval", "END "); 
		
	}

	 private void daoAdminLog(Class<? extends AdminDaoImpl> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}
}
