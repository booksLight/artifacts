package org.nurture.manager.service.impl;

import java.util.List;

import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.slf4j.*;

@Service
public class UserServicesImpl implements UserService {
	private static final Logger logger = LoggerFactory.getLogger(UserServicesImpl.class);
	  @Autowired
	  private UserDao userDao;
	  
	public void addUser(ModelUser user) {
		userDao.addUser(user);
	}

	public ModelUser getUserById(Integer id) {
		return userDao.getUserById(id);
	}

	public List<ModelUser> getAllUsers() {
		return userDao.getAllUsers();
	}

	public ModelUser getUserByName(String username) {
		return userDao.getUserByName(username);
	}
	public ModelUser getUserByMobile(String mobile) {
		return userDao.getUserByMobile(mobile);
	}

	public void saveOrUpdateUserName(ModelUser userParam) {
		if(userParam != null){
			 userDao.updateUserName(userParam);
		}else{
			logger.debug("\n *** UserServicesImpl || Customer Name is Null.");
		}
		
	}

}
