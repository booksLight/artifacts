package org.nurture.manager.service;

import org.nurture.manager.entity.*;
import java.util.List;
import java.util.Set;

public interface ProductService {

    Product getProductById(int id);

    Integer addProduct(Product product);

    void updateProduct(Product product);

    void deleteProduct(Product product);

	List<Product> getProducts(Integer offset, Integer maxResults);
	
	List<Product> getProductsPage(Integer offset, Integer maxResults, String categeoryKey);
	List<Product> getProductsPage(Integer offset, Integer maxResults, String lookUp, String  categeoryKey);
	
	public Long countProducts(String categeoryKey);
	
	Long countProducts(String categeoryKey , String  lookUp);

	Set<Categeory> getCategeories();
	
}
