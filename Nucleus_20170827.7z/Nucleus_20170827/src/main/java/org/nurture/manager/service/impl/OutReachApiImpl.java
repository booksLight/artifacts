package org.nurture.manager.service.impl;

import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.slf4j.*;


public class OutReachApiImpl implements OutReachAPI {

	public void saveOutReacProduct() {
		// TODO Auto-generated method stub

	}

	public OutReach getOutReach() {
		// TODO Auto-generated method stub
		return null;
	}

}
