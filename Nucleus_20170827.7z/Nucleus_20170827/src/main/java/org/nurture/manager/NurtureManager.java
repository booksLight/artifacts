package org.nurture.manager;


import java.net.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.*;
import org.nurture.manager.util.*;
import org.nurture.manager.vo.CartItemsVO;
import org.nurture.manager.vo.CustomerVO;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.ProductVO;
import org.nurture.manager.vo.UserVO;
import org.slf4j.*;

@Component
public class NurtureManager extends BasePkgs {

	private static final Logger logger = LoggerFactory.getLogger(NurtureManager.class);

	@Autowired
	private UserService userService;
	
	@Autowired
	private ClientService clientService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private CartService cartService;

	@Autowired
	CartItemService cartItemService;

	@Autowired
	private CustomerOrderService customerOrderService;

	@Autowired
	private ProductService productService;

	
	

	// Return Root Directory as a String
	public String getContextPath(HttpServletRequest paramReq) {
		return paramReq.getSession().getServletContext().getRealPath("/");
	}

	public String securityCheck(HttpServletRequest paramRequest){
		if(!isUserLoggedOn(paramRequest)){
		return "redirect:/login";
	 }
		return null;
	}
	
	/*
	 * Model Info
	 */
	public ModelBarVo getUserModel(HttpServletRequest paramReq) {
		mgrLog(this.getClass(), "getUserModel", "START");
		ModelBarVo model = getModel(paramReq);
		UserVO userVo = (UserVO) paramReq.getSession().getAttribute(Constants.SESSION_USER);
		mgrLog(this.getClass(), "getUserModel", "USER ===" + (userVo != null ? userVo.toString() : null));
		model.setUserVo(userVo);
		if(userVo != null &&  userVo.getId() != null){
			Customer customer = getCustomerByUserID(userVo.getId());
			if(customer != null && customer.getCart() !=null){
				Cart cart= getCartById(customer.getCart().getCartId());
				if(cart != null){
					model.setCartZize(cart.getCartItems().size());
				}
			}
			}
		mgrLog(this.getClass(), "getUserModel", "END");
		return model;
	}

	/*
	 * Initialize model object
	 */
	public ModelBarVo getModel(HttpServletRequest req) {
		mgrLog(this.getClass(), "getModel", "START");
		ModelBarVo homeModel = new ModelBarVo();
		homeModel.setTitle(new Constants().MODEL_TITILE);
		homeModel.setProduct(Constants.MODEL_PRODUCTS);
		homeModel.setContact(Constants.MODEL_CONTACTS);
		homeModel.setHome(Constants.MODEL_HOME);
		homeModel.setCartEnable(Constants.TRUE);
		mgrLog(this.getClass(), "getModel", "END");
		return homeModel;
	}

	/*
	 * Synched model object with Logged in User
	 */
	public ModelBarVo updateModel(UserVO paramUser, HttpServletRequest paramReq) {
		mgrLog(this.getClass(), "updateModel", "START");
		ModelBarVo model = getModel(paramReq);
		UserVO cuser = updateSession(paramUser, paramReq);
		model.setUserVo(cuser);
		mgrLog(this.getClass(), "updateModel", "END");
		return model;
	}

	/*
	 * Verify the user from the Session
	 */
	public boolean isUserLoggedOn(HttpServletRequest request) {
		mgrLog(this.getClass(), "isUserLoggedOn", "START");
		boolean state = Constants.FALSE;
		state = (request != null ? (request.getSession() != null
				? (request.getSession().getAttribute(Constants.SESSION_USER) != null ? Constants.TRUE : Constants.FALSE)
				: Constants.FALSE) : Constants.FALSE);
		mgrLog(this.getClass(), "isUserLoggedOn", "END->" + state);
		return state;
	}

	/*
	 * Adding user into the session scope if not else return from the session
	 * scope if exist
	 */
	public UserVO updateSession(UserVO user, HttpServletRequest request) {
		mgrLog(this.getClass(), "updateSession", "START");
		UserVO currentUser = null;
		if (request != null & request.getSession() != null) {
			if (request.getSession().getAttribute(Constants.SESSION_USER) != null) {
				currentUser = (UserVO) request.getSession().getAttribute(Constants.SESSION_USER);
				mgrLog(this.getClass(), "updateSession", "fetch the user object from the session");
			} else {
				request.getSession().setAttribute(Constants.SESSION_USER, user != null ? user : null);
				currentUser = user;
				mgrLog(this.getClass(), "updateSession", "add the user object into the session");
			}
		} else {
			mgrLog(this.getClass(), "updateSession", "Request/Session is Null");
		}
		mgrLog(this.getClass(), "updateSession", "END");
		return currentUser;
	}

	// Logout from session if logged in

	public boolean letMeLogOut(HttpServletRequest request) {
		mgrLog(this.getClass(), "letMeLogOut", "START");
		boolean state = Constants.FALSE;
		if (isUserLoggedOn(request)) {
			request.getSession().invalidate();
			mgrLog(this.getClass(), "letMeLogOut", "session invalidated successfully");
		}

		mgrLog(this.getClass(), "letMeLogOut", "END->" + state);
		return state;
	}

	// Mapping UserVO with User
	public UserVO getMapUserVO(ModelUser parmUser) {
		mgrLog(this.getClass(), "getMapUserVO", "START");
		UserVO mappedUser = null;
		if (parmUser != null) {
			mappedUser = new UserVO();
			mappedUser.setId(parmUser.getUserId());
			mappedUser.setName(parmUser.getUsername() != null ? parmUser.getUsername() : parmUser.getUserMobile());
			mappedUser.setEmail(parmUser.getUserEmail() != null ? parmUser.getUserEmail() : null);
			mappedUser.setMobile(parmUser.getUserMobile() != null
					? parmUser.getUserMobile().length() >= 1 ? parmUser.getUserMobile() : null : null);
			mappedUser.setValid(parmUser.isEnabled());
		
			mappedUser.setType((parmUser.getRolId() == Constants.ADM_ID ? Constants.ROL_TYPE_ADM
					: parmUser.getRolId() == Constants.CUST_ID ? Constants.ROL_TYPE_CUS
							: parmUser.getRolId() == Constants.USE_ID ? Constants.ROL_TYPE_USE
									: Constants.ROL_TYPE_VIS));
			mgrLog(this.getClass(), "getMapUserVO", "END->");
		}

		mgrLog(this.getClass(), "getMapUserVO", "USER TYPE =" +mappedUser.getType());
		
		return mappedUser;
	}

	public String getPassCode(String strPram) {
		mgrLog(this.getClass(), "getPassCode", "START");
		return (strPram.substring(0, Math.min(strPram.length(), 3))
				+ strPram.substring(Math.max(strPram.length() - 3, 0)));
	}

	public void mailRegistrationAcknowledgment(ModelUser user) throws AddressException, MessagingException {
		mgrLog(this.getClass(), "mailRegistrationAcknowledgment", "START");
		if (user != null) {
			IMail mail = new MailImpl();
			if (user.getUserEmail() != null && user.getPassword() != null) {
				mail.registrationAcknowledgmet((user.getUserEmail() != null ? user.getUserEmail() : null),
						(user.getPassword() != null ? user.getPassword() : null));
				mgrLog(this.getClass(), "mailRegistrationAcknowledgment", "Registratin AckCode=" + user.getPassword());
			}
		} else {
			mgrLog(this.getClass(), "mailRegistrationAcknowledgment", "Invalid User Object");

			mgrLog(this.getClass(), "mailRegistrationAcknowledgment", "END");
		}
	}

	public void mailOrderAcknowledgment(String custEmail, String custParam, String OrderParam)
			throws AddressException, MessagingException {
		mgrLog(this.getClass(), "mailOrderAcknowledgment", "START");
		if (custEmail != null) {
			String sendto = (custEmail != null ? custEmail : null);
			IMail mail = new MailImpl();

			mail.orderReceipt(sendto, custParam, OrderParam);
			mgrLog(this.getClass(), "mailOrderAcknowledgment", " Order Number  =" + OrderParam);

		} else {
			mgrLog(this.getClass(), "mailOrderAcknowledgment", "Invalid Custoemr emilat");

			mgrLog(this.getClass(), "mailOrderAcknowledgment", "END");
		}
	}

	public Integer getRol(String regType) {
		Privileged access;
		Integer rolId = 0;
		if (regType.equalsIgnoreCase(Constants.ROL_TYPE_ADM)) {
			access = Privileged.ADMIN;
			rolId = access.getAccessCode();
		}
		if (regType.equalsIgnoreCase("CUSTOMER")) {
			access = Privileged.CUSTOMER;
			rolId = access.getAccessCode();
		}
		if (regType.equalsIgnoreCase("USER")) {
			access = Privileged.USER;
			rolId = access.getAccessCode();
		}
		if (regType.equalsIgnoreCase("VISITOR")) {
			access = Privileged.VISITOR;
			rolId = access.getAccessCode();
		}
		return rolId;
	}

	public Customer getCustomerByUser(HttpServletRequest paramRequest) {
		mgrLog(this.getClass(), "getCustomerByUser", "START");

		// Fetching looged user from the session
		UserVO curentUser = updateSession(null, paramRequest);

		if (curentUser != null) {
			mgrLog(this.getClass(), "getCustomerByUser", "END with Customer");
			return getCustomerByUserID(curentUser.getId());
		}
		mgrLog(this.getClass(), "getCustomerByUser", "END with null");
		return null;
	}

	public void updateUserName(Customer customerParam) {
		mgrLog(this.getClass(), "updateUserName", "START");
		if (customerParam != null) {

			ModelUser useParam = new ModelUser();

			useParam.setUsername(customerParam.getCustomerName());
			useParam.setRolId(getRol("CUSTOMER"));
			useParam.setUserId(customerParam.getUserId());
			try {
				userService.saveOrUpdateUserName(useParam);
			} catch (Exception e) {
				mgrLog(this.getClass(), "updateUserName", "Exception :" + e.getMessage());
			}
		} else {
			mgrLog(this.getClass(), "updateUserName", "Customer is null...Over");
		}
		mgrLog(this.getClass(), "getCustomerByUser", "END ");
	}

	// Migration

	public List<OrderBook> mapOrderBookOnCustomerOrder(CustomerOrder customerNewOrder) {
		mgrLog(this.getClass(), "mapOrderBookOnCustomerOrder", "START ");
		if (customerNewOrder != null) {
			List<CartItem> cartItems = customerNewOrder.getCart() != null
					? customerNewOrder.getCart().getCartItems() != null ? customerNewOrder.getCart().getCartItems()
							: null
					: null;
			if (cartItems != null) {
				OrderBook orderBook = null;
				List<OrderBook> orderBooks = new ArrayList<OrderBook>();
				for (CartItem orderItem : cartItems) {
					orderBook = new OrderBook();

					orderBook.setOrderId(customerNewOrder.getCustomerOrderId());
					orderBook.setCartId(orderItem.getCart().getCartId());
					orderBook.setCartItemId(orderItem.getCartItemId());
					orderBook.setProductId(orderItem.getProduct().getProductId());
					orderBook.setQuantity(orderItem.getQuantity());
					orderBook.setTotalPrice(orderItem.getTotalPrice());

					orderBooks.add(orderBook);
				}
				mgrLog(this.getClass(), "mapOrderBookOnCustomerOrder", "END with List of Orrdered Items");
				return orderBooks;
			}
		}
		mgrLog(this.getClass(), "mapOrderBookOnCustomerOrder", "END ");
		return null;
	}

	// Saved Cartitems to OrderBook
	public void saveOrUpdateOrderedItems(List<OrderBook> orderedItems) {
		mgrLog(this.getClass(), "saveOrUpdateOrderedItems", "START ");
		if (orderedItems != null) {
			for (OrderBook orderBook : orderedItems) {
				customerOrderService.saveOrUpdateOrderBook(orderBook);
			}
		}
		mgrLog(this.getClass(), "saveOrUpdateOrderedItems", "END ");
	}

	// Removing cart items after successfully placed ordered
	public void deleteOrderedItemsFromCart(CustomerOrder orderedRef) {
		mgrLog(this.getClass(), "deleteOrderedItemsFromCart", "START");
		if (orderedRef != null) {
			if (orderedRef.getCart() != null) {
				for (CartItem orderItem : orderedRef.getCart().getCartItems()) {
					cartItemService.removeCartItemById(orderItem.getCartItemId());
				}
			}
		}
		mgrLog(this.getClass(), "deleteOrderedItemsFromCart", "END ");
	}

	// Fetchs Customer Orders by cartId
	public List<CustomerOrder> getCustomerOrdersByCartId(Integer cartId) {
		mgrLog(this.getClass(), "getCustomerOrdersByCartId", "START for "+ cartId);
		List<CustomerOrder> ordered = null;
		if (cartId > 0) {
			ordered = customerOrderService.getCustomerOrdersByCartId(cartId);
		}
		mgrLog(this.getClass(), "getCustomerOrdersByCartId", "END for "+ cartId);
		return ordered;
	}

	// Fetch Customer Order by customerOrderId
	public CustomerOrder getCustomerOrderById(final Integer customerOrderId) {
		mgrLog(this.getClass(), "getCustomerOrderById", "START ");
		CustomerOrder customerOrder = null;
		if (customerOrderId > 0) {
			customerOrder = customerOrderService.getCustomerOrderById(customerOrderId);
		

			if (customerOrder != null) {
				if (customerOrder.getCart() != null) {
					double grandTotal = 0.0;
					List<CartItem> cartItems = null;
					if (customerOrder.getCart().getCartItems() != null) {
						logger.debug("\n\n ************* SIZE of the Customer CartItems = "
								+ customerOrder.getCart().getCartItems().size());
						cartItems = new ArrayList<CartItem>();
						for (OrderBook orderBook : getCustomerOrderedBooks(customerOrderId)) {
							CartItem cartItem = new CartItem();
							cartItem.setCartItemId(orderBook.getCartItemId());
							Product tempProduct =getProductById(orderBook.getProductId());							
							cartItem.setProduct(tempProduct);
							cartItem.setQuantity(orderBook.getQuantity());
							cartItem.setTotalPrice(orderBook.getTotalPrice());
							cartItems.add(cartItem);
							grandTotal = (grandTotal + orderBook.getTotalPrice());
						}

					}
					customerOrder.getCart().setCartItems(cartItems);

					customerOrder.getCart().setGrandTotal(grandTotal);
				}
			}
		}

		mgrLog(this.getClass(), "getCustomerOrderById",
				"END with Order Details " + customerOrder.getCart().getCartItems().size());

		return customerOrder;
	}

	
	//Featch Products with criteria for Pagination 
	public List<ProductMapper> lookUptProducts(String  categeoryKey, String lookUp, Integer offset, Integer maxResults) {
		mgrLog(this.getClass(), "lookUptProducts",
				"START with (offset,maxResults) :: " + (offset * 5) + "," + maxResults + "  CATEGORY = "+categeoryKey + "  LookUp ="+lookUp);
		List<ProductMapper> products;
		List<Product> prods;
		ProductMapper mapper;
		mgrLog(this.getClass(), "lookUptProducts", "END");
		
		if(categeoryKey.equalsIgnoreCase("REB")){
			prods = productService.getProductsPage((offset * 5), (maxResults), categeoryKey, lookUp);
		}else{		
			prods = productService.getProductsPage((offset * 5), (maxResults), categeoryKey);
		}
		
		if(prods != null){
			products = new ArrayList<ProductMapper>();
			for(Product prd : prods){
				mapper = new ProductMapper();
				mapper.setId(prd.getProductId() > 0 ? prd.getProductId() : 0);
				mapper.setProductName(prd.getProductName() != null ? prd.getProductName() : "NA");
				mapper.setProductCategory(prd.getProductCategory() !=null ? prd.getProductCategory() : "NA");
				mapper.setProductCondition(prd.getProductCondition() !=null ? prd.getProductCondition() : "NA");
				mapper.setProductPrice(prd.getProductPrice() >0 ? prd.getProductPrice() : 0.0);
				mapper.setProductManufacture(prd.getProductManufacture() !=null ? prd.getProductManufacture() : "NA");
				products.add(mapper);	
			}
			return products;
		}
		return new ArrayList<ProductMapper>();
	}

	public Long getCountProducts(String categeoryKey) {
		mgrLog(this.getClass(), "getCountProducts", "START");

		Long total = productService.countProducts(categeoryKey);

		mgrLog(this.getClass(), "getCountProducts", "END");
		return total;
	}
	
	public Long getCountProducts(String categeoryKey , String  lookUp) {
		mgrLog(this.getClass(), "getCountProducts("+categeoryKey+","+lookUp+")", "START");
		Long total;
		if(categeoryKey.equalsIgnoreCase("REB")){
			total = productService.countProducts(categeoryKey,lookUp);
		}else{
			total = productService.countProducts(categeoryKey);
		}
		mgrLog(this.getClass(), "getCountProducts :"+total, "END");
		return total;
	}
	

	// Fetching All Products
	public List<Product> getAllProduts(Integer offset, Integer maxResults ) {
		logger.info("\n Manager getAllProduts( "+offset+", "+maxResults+") ");
		List<Product> products = productService.getProducts(offset, maxResults);
		if (products != null) {
			logger.info("\n Total Products found ="+products.size());
			return products;
		} else {
			logger.info("\n Products is empity or null");
		}
		return new ArrayList<Product>();
	}

	// Calculating MaxPages based of offset for pagination
	public Integer initPaginition(int offSet, String categeoryKey, String  lookup) {
		mgrLog(this.getClass(), "initPaginition", "START");
		Long pLength;
		if(categeoryKey.equalsIgnoreCase("REB")){
			pLength = getCountProducts(categeoryKey, lookup);
		}else {
			pLength = getCountProducts(categeoryKey);
		}
		System.out.println( "\n\t %%%%%%% page Products ="+pLength);
		
		Integer fixedPageSize = 5;
		Integer maxResults = 0;
		int offSetVal = offSet * fixedPageSize;  //0
		if ((offSetVal + fixedPageSize) < pLength) { 
			maxResults = offSetVal + fixedPageSize; 
		} else {
			maxResults = pLength.intValue();
		}
		mgrLog(this.getClass(), "initPaginition", "END with maxResults =" + maxResults);
		return maxResults;
	}

	// Calculating Total Pages for pagination
	public List<Integer> getTotalPages(String categeoryKey, String lookUp) {
		mgrLog(this.getClass(), "getTotalPages", "START  to lookup  pages for  =" + lookUp);
		Long pLength = getCountProducts(categeoryKey, lookUp);
		Integer fixedPageSize = 5;
		Integer count = 0;

		List<Integer> pages = new ArrayList<Integer>();

		for (int i = 0; i < pLength; i = (i += fixedPageSize)) {
			count++;
			pages.add(count);
		}

		mgrLog(this.getClass(), "getTotalPages", "END with pages =" + pages.size());

		return pages;
	}

	

	
	
	
	
	
	// Generic Logger
		public void mgrLog(Class<? extends NurtureManager> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}

		
		
		public Customer getCustomerByUserID(int userId) {
			mgrLog(this.getClass(), "getCustomerByUserID", "START for "+ userId);
			return	customerService.getCustomerByUserID(userId);
		}

		public boolean updateShippingAddress(Customer existCustomer) {
			mgrLog(this.getClass(), "updateShippingAddress", "START  ");
				return 	customerService.updateShippingAddress(existCustomer);
		}

		public Cart getCartById(int cartId) {
			mgrLog(this.getClass(), "getCartById", "START for "+ cartId);
			 return cartService.getCartById(cartId);
		}

		public void addCustomerOrder(CustomerOrder customerNewOrder) {
			mgrLog(this.getClass(), "addCustomerOrder", "START  ");
			customerOrderService.addCustomerOrder(customerNewOrder);	
			mgrLog(this.getClass(), "addCustomerOrder", "END  ");
		}

		public Product getProductById(int productId) {
			mgrLog(this.getClass(), "getCartById", "START for "+ productId);
			return productService.getProductById(productId);
		}

		public void addCartItem(CartItem cartItem) {
			mgrLog(this.getClass(), "addCartItem", "START  ");
			 cartItemService.addCartItem(cartItem);		
			 mgrLog(this.getClass(), "addCartItem", "END  ");
		}

		public void removeCartItemById(int cartItemId) {
			mgrLog(this.getClass(), "removeCartItemById", "START for "+ cartItemId);
			 cartItemService.removeCartItemById(cartItemId);
			mgrLog(this.getClass(), "removeCartItemById", "END for "+ cartItemId);
		}

		public void removeAllCartItems(Cart cart) {
			mgrLog(this.getClass(), "removeAllCartItems", "START ");
			cartItemService.removeAllCartItems(cart);	
			mgrLog(this.getClass(), "removeAllCartItems", "END ");
		}

		public List<Customer> getAllCustomers() {
			mgrLog(this.getClass(), "getAllCustomers", "START ");
			return customerService.getAllCustomers();
		}
		
		// Return Referral Request to get Back on previous page
		public URL getReferral(HttpServletRequest paramRequest) {
			mgrLog(this.getClass(), "getReferral", "START ");
			URL url = null;
			try {
				if(paramRequest.getHeader("Referer") != null){
					url = new URL(paramRequest.getHeader("Referer"));
					mgrLog(this.getClass(), "getReferral", " Referer : true");
					return url;
				}
				mgrLog(this.getClass(), "getReferral", " Referer : false");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			mgrLog(this.getClass(), "getReferral", "END ");
			return null;
		}

		public ModelUser getUserByMobile(String userMobile) {
			mgrLog(this.getClass(), "getUserByMobile","" +userMobile);
			return userService.getUserByMobile(userMobile);
		}
		
		
		// Calculate per Cart total  Order Amount 
		public Double calculateOrderTotalAmt(final Cart cart){
			double cartGrandTotal = 0.0;
			for(CartItem item : cart.getCartItems()){    			
    			if(item.getProduct() != null){
    				cartGrandTotal += item.getProduct().getProductPrice();
    			}    			
    		}
			return cartGrandTotal;
		}
		
	private List<OrderBook> getCustomerOrderedBooks(final Integer customerOrderId)	{
			return customerOrderService.getOrderedBooksByOrderId(customerOrderId);
	}

	public Map<String,String> getCategories() {
		mgrLog(this.getClass(), "getCategories","START");
		Set<Categeory> categories = productService.getCategeories();
		mgrLog(this.getClass(), "getCategories", ""+categories.size());
		Map<String,String> categeoryMap = new TreeMap<String, String>();
		for(Categeory categeory : categories){
			categeoryMap.put(categeory.getCatCode(), categeory.getCatName());
		}
		
		mgrLog(this.getClass(), "getCategories","END");
		return categeoryMap;
	}

	public void updateCustomer(Customer customerDet) {
		mgrLog(this.getClass(), "updateCustomer","START");
		customerService.addCustomer(customerDet);
		mgrLog(this.getClass(), "updateCustomer","END");
		
	}

	public CustomerVO mapCustomerVO(final Integer userId) {
		mgrLog(this.getClass(), "mapCustomerVO"," START :: mapping customer object to the value object ");
		CustomerVO vo = null ;
		if(userId > 0){
			Customer customer =	getCustomerByUserID(userId);
			vo = new  CommonUtil().mapCustomerToCustomerVO(vo, customer);
			mgrLog(this.getClass(), "mapCustomerVO"," END :: mapped customer object to the value object ");
			return vo != null ? vo: new CustomerVO();			
		}
		mgrLog(this.getClass(), "mapCustomerVO"," END :: user object is null ");
		return null;
	}

	public void appliedCustomerCoupon(final CustomerVO customerVO) {
		if(customerVO.getCustomerId() >0 && customerVO.getAppliedCoupon() > 0){
		mgrLog(this.getClass(), "appliedCustomerCoupon("+customerVO.getAppliedCoupon()+", "+customerVO.getCustomerId()+")", "START");
		 customerService.updateAvailedCoupon(customerVO.getAppliedCoupon(), "True", customerVO.getCustomerId());
		 customerService.updateCustomerAvailedCoupon(customerVO.getAppliedCoupon(), customerVO.getCustomerId());
		mgrLog(this.getClass(), "appliedCustomerCoupon("+customerVO.getAppliedCoupon()+")", "END : successfully");
		}
	}

	public void calculateDiscountAmt( Cart cart, final Customer customer) {
		mgrLog(this.getClass(), "calculateDiscountAmt", "START : calculating discount..");
		if(customer != null){
			int availedCouponId = customer.getCouponId() != null ? customer.getCouponId() : 0;
			
			if (customer.getCoupons() != null) {
				for(Coupon coupon : customer.getCoupons()){
					logger.info("\n\n Coupons Details =" +coupon.getCouponId() +"  "+coupon.getTitle()+",\n Percent= "+coupon.getPercent()+", \n Amount = "+coupon.getValueRs());
					double couponPercent = 0.0;
					double couponAmt = 0.0 ;
					if(coupon.getCouponId() == availedCouponId){
						couponPercent = coupon.getPercent();
						couponAmt = coupon.getValueRs();
							logger.info("\n AVAILED Coupons Details =" +coupon.getCouponId() +"  "+coupon.getTitle()+",\n Percent= "+coupon.getPercent()+", \n Amount = "+coupon.getValueRs());
							if(couponAmt > 0){
							cart.setDiscountAmt(couponAmt);
							}
							if(couponPercent > 0){
								cart.setDiscountAmt( cart.getGrandTotal() / couponPercent); 
							}
					}
			}
			
		}
		
		mgrLog(this.getClass(), "calculateDiscountAmt", "START : discount calculated...");
	}
}
	
}
