package org.nurture.manager.vo;

import java.util.Map;
import java.util.Set;

import org.nurture.manager.entity.BillingAddress;
import org.nurture.manager.entity.Cart;
import org.nurture.manager.entity.Coupon;
import org.nurture.manager.entity.ShippingAddress;

public class CustomerVO {

	private int customerId;
	private String customerName;

	private String customerEmail;

	private String customerPhone;

	private Integer userId;

	private boolean enabled;

	private Integer appliedCoupon;

	private Map<Integer, String> mapCoupon;

	
	private BillingAddress billingAddress;

	private ShippingAddress shippingAddress;

	private Cart cart;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Integer getAppliedCoupon() {
		return appliedCoupon;
	}

	public void setAppliedCoupon(Integer appliedCoupon) {
		this.appliedCoupon = appliedCoupon;
	}

	public Map<Integer, String> getMapCoupon() {
		return mapCoupon;
	}

	public void setMapCoupon(Map<Integer, String> mapCoupon) {
		this.mapCoupon = mapCoupon;
	}

	
	public BillingAddress getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(BillingAddress billingAddress) {
		this.billingAddress = billingAddress;
	}

	public ShippingAddress getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(ShippingAddress shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	
}
