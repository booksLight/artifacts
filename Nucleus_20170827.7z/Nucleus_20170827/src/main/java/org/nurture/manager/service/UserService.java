package org.nurture.manager.service;

import org.nurture.manager.entity.*;
import java.util.List;



public interface UserService {

	void addUser(ModelUser user);

	ModelUser getUserById(Integer id);

	List<ModelUser> getAllUsers();

	ModelUser getUserByName(String username);
	
	ModelUser getUserByMobile(String mobile);

	void saveOrUpdateUserName(ModelUser userParam);
}
