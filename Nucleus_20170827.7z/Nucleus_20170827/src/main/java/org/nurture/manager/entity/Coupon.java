package org.nurture.manager.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class Coupon {

	 private static final long serialVersionUID = -88906953118002L;
	 
	  @Id
	    @GeneratedValue
	    private int couponId;
	  
	  	@Column private String title;
		@Column private double valueRs;
		@Column private double percent;
		@Column private String terms;
		@Column private boolean isActive;
		@Column private boolean isAvailed;
		@Column private int cart;
	  	  	
		  @OneToOne
		  @JoinColumn(name = "customerId")
		  @JsonIgnore
		  private Customer customer;
	   
		public Coupon() {}

		public int getCouponId() {
			return couponId;
		}

		public void setCouponId(int couponId) {
			this.couponId = couponId;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		
		public double getValueRs() {
			return valueRs;
		}

		public void setValueRs(double valueRs) {
			this.valueRs = valueRs;
		}

		public double getPercent() {
			return percent;
		}

		public void setPercent(double percent) {
			this.percent = percent;
		}

		public String getTerms() {
			return terms;
		}

		public void setTerms(String terms) {
			this.terms = terms;
		}

		public Customer getCustomer() {
			return customer;
		}

		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

		public boolean isActive() {
			return isActive;
		}

		public void setActive(boolean isActive) {
			this.isActive = isActive;
		}

		public boolean isAvailed() {
			return isAvailed;
		}

		public void setAvailed(boolean isAvailed) {
			this.isAvailed = isAvailed;
		}

		public int getCart() {
			return cart;
		}

		public void setCart(int cart) {
			this.cart = cart;
		}

		
}
