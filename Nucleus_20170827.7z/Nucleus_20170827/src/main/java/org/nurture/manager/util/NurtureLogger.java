package org.nurture.manager.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class NurtureLogger {

	private static Logger logger = LoggerFactory.getLogger(NurtureLogger.class);
	
	public abstract void ctrLog(Class<? extends Object> paramCclass, String paramMethod, String paramMsg);
}
