package org.nurture.manager.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.nurture.manager.entity.BillingAddress;
import org.nurture.manager.entity.Coupon;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.ShippingAddress;
import org.nurture.manager.vo.CustomerVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonUtil {

	private static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);

	public void renderCustomers(List<Customer> customers) {
		utilLog(this.getClass(), "renderCustomers", " Customers details :");
		if (customers != null && customers.size() > 0) {
			for (Customer customer : customers) {
				renderCustomer(customer);
			}
		}
	}

	public void renderCustomer(Customer customer) {
		utilLog(this.getClass(), "renderCustomer", " Customer details :");
		if (customer != null) {
			logger.info("ID =" + customer.getCustomerId() + "\n Name =" + customer.getCustomerName() + "\n Coupons = "
					+ customer.getCoupons().size());

			if (customer.getShippingAddress() != null) {
				ShippingAddress shipping = customer.getShippingAddress();
				logger.info("ShippingAddress Details [shippingAddressId=]" + shipping.getShippingAddressId()
						+ ", streetName=" + shipping.getStreetName() + ", apartmentNumber="
						+ shipping.getApartmentNumber() + ", city=" + shipping.getCity() + ", state="
						+ shipping.getState() + ", country=" + shipping.getCountry() + ", zipCode="
						+ shipping.getZipCode());
			}

			if (customer.getBillingAddress() != null) {
				BillingAddress billing = customer.getBillingAddress();
				logger.info("BillingAddress Details [billingAddressId=]" + billing.getBillingAddressId()
						+ ", streetName=" + billing.getStreetName() + ", apartmentNumber="
						+ billing.getApartmentNumber() + ", city=" + billing.getCity() + ", state=" + billing.getState()
						+ ", country=" + billing.getCountry() + ", zipCode=" + billing.getZipCode());
			}
			
			if (customer.getCoupons() != null) {
				for(Coupon coupon : customer.getCoupons())
				logger.info("Coupons Details =" +coupon.getCouponId() +"  "+coupon.getTitle());
			}

		}
	}

	

	public CustomerVO mapCustomerToCustomerVO(CustomerVO vo, final Customer customer) {
		utilLog(this.getClass(), "mapCustomerToCustomerVO"," START :: mapping customer object to the value object ");
			if(customer != null){
				Map<Integer, String> mapCoupons;
				vo = new CustomerVO();
				vo.setCustomerId(customer.getCustomerId());
				vo.setCustomerName(customer.getCustomerName());
				vo.setCustomerPhone(customer.getCustomerPhone());
				vo.setCustomerEmail(customer.getCustomerEmail());				
				vo.setCart(customer.getCart());
				vo.setBillingAddress(customer.getBillingAddress());
				vo.setShippingAddress(customer.getShippingAddress());
				
				 mapCoupons = new HashMap<Integer, String>();
				 for(Coupon coupon : customer.getCoupons()){	
					 if(coupon.isActive()){
						 if(!coupon.isAvailed())
							 mapCoupons.put(coupon.getCouponId(), coupon.getTitle() +" "+ (coupon.getPercent() > 0 ? coupon.getPercent()+"%" :"Rs."+coupon.getValueRs()));
					 }
				 }
					 vo.setMapCoupon(mapCoupons);
					 utilLog(this.getClass(), "mapCustomerToCustomerVO"," END :: mapped customer object to the value object ");
				return vo;
			}
		return null;
	}
	
	
	// Generic Logger for this class
		private void utilLog(Class<? extends CommonUtil> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}
}
