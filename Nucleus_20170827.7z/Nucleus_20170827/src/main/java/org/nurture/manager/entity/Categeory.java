package org.nurture.manager.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="categeory")
public class Categeory {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Column(name="cat_id") private Integer catId;
	@Column(name="cat_code") private String catCode;
	@Column(name="cat_name") private String catName;
	@Column(name="isActive") private boolean isActive;
	
	public Categeory() {
	}
		
	public Categeory(String catCode, String catName, boolean isActive) {
		this.catCode = catCode;
		this.catName = catName;
		this.isActive = isActive;
	}


	public Integer getCatId() {
		return catId;
	}
	public void setCatId(Integer catId) {
		this.catId = catId;
	}
	public String getCatCode() {
		return catCode;
	}
	public void setCatCode(String catCode) {
		this.catCode = catCode;
	}
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "Categeory [catId=" + catId + ", catCode=" + catCode + ", catName=" + catName + ", isActive=" + isActive
				+ "]";
	}
	
	
}
