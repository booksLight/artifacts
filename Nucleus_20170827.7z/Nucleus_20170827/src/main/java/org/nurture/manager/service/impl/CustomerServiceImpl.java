package org.nurture.manager.service.impl;

import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.slf4j.*;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    private CustomerDao customerDao;

    public void addCustomer(Customer customer) {
        customerDao.addCustomer(customer);
    }

    public Customer getCustomerById(Integer id) {
        return customerDao.getCustomerById(id);
    }

    public List<Customer> getAllCustomers() {
        return customerDao.getAllCustomers();
    }

    public Customer getCustomerByUsername(String username) {
        return customerDao.getCustomerByUsername(username);
    }

	public Customer getCustomerByUserID(Integer userId) {
		 return customerDao.getCustomerByUserID(userId);
	}

	public boolean updateShippingAddress(Customer customerParam) {
		return customerDao.updateShippingAddress(customerParam);
	}

	public boolean updateAvailedCoupon(int couponID, String flagValue, final int cartKey) {	
		return customerDao.updateAvailedCoupon(couponID, flagValue, cartKey);
	}

	public boolean updateCustomerAvailedCoupon(int couponID, int custmerID) {
		return customerDao.updateCustomerAvailedCoupon(couponID, custmerID);
	}
}
