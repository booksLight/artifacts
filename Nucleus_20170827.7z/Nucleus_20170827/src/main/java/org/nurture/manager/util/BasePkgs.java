package org.nurture.manager.util;


public abstract class BasePkgs {

}
