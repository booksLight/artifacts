package org.nurture.manager.service;

import org.nurture.manager.entity.*;

public interface OutReachAPI {

	public void saveOutReacProduct();
	public OutReach getOutReach();
}
