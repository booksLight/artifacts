package org.nurture.manager.service.impl.dao;

import java.util.List;
import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.data.repository.*;


public interface CustomerDao {

    void addCustomer(Customer customer);

    Customer getCustomerById(Integer id);

    List<Customer> getAllCustomers();

    Customer getCustomerByUsername(String username);

	Customer getCustomerByUserID(Integer userId);

	boolean updateShippingAddress(Customer customerParam);
	
	public boolean updateAvailedCoupon(int couponID, String flagValue, int cartKey);
	
	public boolean updateCustomerAvailedCoupon( int couponID, int custmerID);
}
