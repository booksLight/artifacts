package org.nurture.manager.service;

import org.nurture.manager.entity.*;

public interface CartService {
    Cart getCartById(int id);

    void update(Cart cart);

	void updateGrandTotal(Cart cart);
}
