package org.nurture.manager.service.impl;

import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.nurture.manager.service.impl.dao.impl.CartItemDaoImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;



@Service
public class CartItemServiceImpl implements CartItemService {

	private static final Logger logger = LoggerFactory.getLogger(CartItemServiceImpl.class);
	
    @Autowired
    private CartItemDao cartItemDao;

    public void addCartItem(CartItem cartItem) {
    	svcLog(this.getClass(), "addCartItem", "START");     	
        cartItemDao.addCartItem(cartItem);
        svcLog(this.getClass(), "addCartItem", "END"); 
    }

    public void removeCartItem(CartItem cartItem) {
    	svcLog(this.getClass(), "removeCartItem", "START"); 
        cartItemDao.removeCartItem(cartItem);
        svcLog(this.getClass(), "removeCartItem", "END"); 
    }

    public void removeAllCartItems(Cart cart) {
    	svcLog(this.getClass(), "removeAllCartItems", "START"); 
        cartItemDao.removeAllCartItems(cart);
        svcLog(this.getClass(), "removeAllCartItems", "END"); 
    }

    public CartItem getCartItemByProductId(int productId) {
    	svcLog(this.getClass(), "getCartItemByProductId", "START"); 
        return cartItemDao.getCartItemByProductId(productId);
    }

	public void removeCartItemById(Integer cartItemId) {
		svcLog(this.getClass(), "removeCartItemById", "START"); 		
		 cartItemDao.removeCartItemById(cartItemId);
		 svcLog(this.getClass(), "removeCartItemById", "END"); 
	}

	public CustomerOrder getCustomerOrderById(Integer customerOrderId) {
		 svcLog(this.getClass(), "getCustomerOrderById", "START"); 
		 
		 svcLog(this.getClass(), "getCustomerOrderById", "END"); 
		return null;
	}
	
	private void svcLog(Class<? extends CartItemServiceImpl> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
	}
}
