package org.nurture.manager.service.impl;

import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.slf4j.*;

import java.util.List;

@Service
public class CustomerOrderServiceImpl implements CustomerOrderService {

	private static final Logger logger = LoggerFactory.getLogger(CustomerOrderServiceImpl.class);
	
    @Autowired
    private CustomerOrderDao customerOrderDao;

    @Autowired
    private CartService cartService;

    public void addCustomerOrder(CustomerOrder customerOrder) {
        customerOrderDao.addCustomerOrder(customerOrder);
    }

    public double getCustomerOrderGrandTotal(int cartId) {
        double grandTotal = 0;
        Cart cart = cartService.getCartById(cartId);
        List<CartItem> cartItems = cart.getCartItems();

        for (CartItem item : cartItems) {
            grandTotal += item.getTotalPrice();
        }

        return grandTotal;
    }

	public void saveOrUpdateOrderBook(OrderBook orderBookParam) {
		customerOrderDao.saveOrUpdateOrderBook(orderBookParam);		
	}

	public CustomerOrder getCustomerOrderById(Integer customerOrderId) {
		return customerOrderId > 0 ?  customerOrderDao.getCustomerOrderById(customerOrderId):null;
	}

	public List<OrderBook> getOrderedBooksByOrderId(Integer customerOrderId) {
		return customerOrderId > 0 ?  customerOrderDao.getOrderedBooksByOrderId(customerOrderId):null;
	}

	public List<CustomerOrder> getCustomerOrdersByCartId(Integer cartId) {
		logger.info("\n\t CustomerOrderServiceImpl : Fetching Customer Order by cartid="+cartId);
		return cartId > 0 ?  customerOrderDao.getCustomerOrdersByCartId(cartId):null;
	}
}
