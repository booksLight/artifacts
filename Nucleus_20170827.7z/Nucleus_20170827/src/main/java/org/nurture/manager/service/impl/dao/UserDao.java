package org.nurture.manager.service.impl.dao;

import java.util.List;
import org.nurture.manager.entity.*;

/**
 * Created by Rakesh on 14.01.2017.
 */
public interface UserDao {

	void addUser(ModelUser user);

	ModelUser getUserById(Integer id);

	List<ModelUser> getAllUsers();

	ModelUser getUserByName(String username);
	
	ModelUser getUserByMobile(String mobile);

	void updateUserName(ModelUser userParam);
}
