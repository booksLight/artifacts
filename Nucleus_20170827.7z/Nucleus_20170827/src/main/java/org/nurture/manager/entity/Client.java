package org.nurture.manager.entity;

public class Client {

	
}
