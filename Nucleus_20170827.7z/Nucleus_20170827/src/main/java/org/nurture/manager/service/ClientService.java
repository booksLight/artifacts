package org.nurture.manager.service;

import org.nurture.manager.entity.*;
import org.springframework.data.domain.*;

public interface ClientService {
	Page<Client> getClientsByPage(Pageable pageable);
}
