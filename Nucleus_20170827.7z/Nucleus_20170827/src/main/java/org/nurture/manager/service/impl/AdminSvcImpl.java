package org.nurture.manager.service.impl;

import java.util.List;

import org.nurture.manager.entity.*;
import org.nurture.manager.mapper.OrderMapper;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;


@Service
public class AdminSvcImpl implements AdminSvc {
	
	private static final Logger logger = LoggerFactory.getLogger(AdminSvcImpl.class);

	 @Autowired
	 private AdminDao adminDao;
	 
	public List<OrderMapper> getOrdersRowMapper() {
		svcAdminLog(this.getClass(), "getOrdersRowMapper", "START");
		return adminDao.getOrdersRowMapper();
	}

	

	public void confirmOrderedProduct(final Integer productKey) {
		svcAdminLog(this.getClass(), "confirmOrderedProduct", "START");
		if(productKey>0){
			adminDao.orderedApproval(productKey);
		}
		svcAdminLog(this.getClass(), "confirmOrderedProduct", "END");
	}



	public void shipOrderedProduct(final Integer productKey) {
		svcAdminLog(this.getClass(), "shipOrderedProduct", "START");
		if(productKey>0){
			adminDao.shipmentApproval(productKey);
		}
		svcAdminLog(this.getClass(), "shipOrderedProduct", "END");
	}
	
	 private void svcAdminLog(Class<? extends AdminSvcImpl> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		}

}
