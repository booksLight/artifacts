package org.nurture.manager.service;

import java.util.List;

import org.nurture.manager.mapper.OrderMapper;


public interface AdminSvc {

	List<OrderMapper> getOrdersRowMapper();
	
	void confirmOrderedProduct(Integer orderKey);
	
	void shipOrderedProduct(Integer orderKey);
}
