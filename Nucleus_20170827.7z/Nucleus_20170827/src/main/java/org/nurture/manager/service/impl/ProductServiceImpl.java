package org.nurture.manager.service.impl;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.dao.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.*;
import org.slf4j.*;

import java.util.List;
import java.util.Set;

@Service
public class ProductServiceImpl implements ProductService {

	private static final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
	
    @Autowired
    private ProductDao productDao;


    public Product getProductById(int id) {
        return productDao.getProductById(id);
    }

    public Integer addProduct(Product product) {
        return productDao.addProduct(product);
    }

    public void updateProduct(Product product) {
        productDao.updateProduct(product);
    }

    public void deleteProduct(Product product) {
        productDao.deleteProduct(product);
    }
	

	public Long countProducts(String categeoryKey) {
		return productDao.countProducts(categeoryKey);
	}

	public Long countProducts(String categeoryKey, String lookUp ) {
		return productDao.countProducts(categeoryKey, lookUp);
	}
	
	public List<Product> getProductsPage(Integer offset, Integer maxResults, String categeoryKey) {
		return productDao.getProductsPage(offset, maxResults, categeoryKey);
	}
	
	public List<Product> getProductsPage(Integer offset, Integer maxResults, String categeoryKey , String lookUp) {
		return productDao.getProductsPage(offset, maxResults, categeoryKey, lookUp);
	}

	public Set<Categeory> getCategeories() {
		return productDao.getCategeories();
	}

	public List<Product> getProducts(Integer offset, Integer maxResults) {
		logger.info("\n Service :  getAllProduts( "+offset+", "+maxResults+") ");
		return productDao.getProducts(offset, maxResults);
	}
}
