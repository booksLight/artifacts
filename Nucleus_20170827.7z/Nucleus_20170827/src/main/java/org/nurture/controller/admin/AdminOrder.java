package org.nurture.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.nurture.controller.*;
import org.nurture.manager.*;
import org.nurture.manager.entity.*;
import org.nurture.manager.service.*;
import org.nurture.manager.service.impl.*;
import org.nurture.manager.mapper.OrderMapper;
import org.nurture.manager.service.AdminSvc;
import org.slf4j.*;
import java.util.List;

import javax.servlet.http.*;
import javax.validation.*;

@RestController
@RequestMapping("/admin")
public class AdminOrder {

	private static final Logger logger = LoggerFactory.getLogger(AdminOrder.class);
	
    @Autowired
    private AdminSvc adminSvc;

	@Autowired
	NurtureManager manager;
	
	 
		@GetMapping(value = "/repo", produces = "application/json")
	    public List<OrderMapper> getTotalOrdersReport(Model model, HttpServletRequest paramRequest) {
	    	ctrAdminLog(this.getClass(), "getTotalOrdersReport", "START");
	    	List<OrderMapper> trakOrders =  adminSvc.getOrdersRowMapper();
	    	if(trakOrders != null){
	    		for(OrderMapper ord : trakOrders){
	    			 logger.debug("\n *** \t AdminOrder (Controller) =  :"+ord.toString());
	    		}
	    	}
	    	
	    	ctrAdminLog(this.getClass(), "getTotalOrdersReport", "END-->");
	        return trakOrders;
	       
	    }
	
	
		@PostMapping(value = "/action/conf/{id}")
		public void doConfirmOrderedProduct(@PathVariable("id") int orderedKey, Model model, HttpServletRequest paramRequest) {
			ctrAdminLog(this.getClass(), "doConfirmOrderedProduct", "START");
			if(orderedKey > 0){
				adminSvc.confirmOrderedProduct(orderedKey);
			}
			logger.debug("\n\t *********************** -> ID = "+orderedKey);
			ctrAdminLog(this.getClass(), "doConfirmOrderedProduct", "END");
		}
    
		@PostMapping(value = "/action/ship/{id}")
		public void doShipOrderedProduct(@PathVariable("id") int orderedKey, Model model, HttpServletRequest paramRequest) {
			ctrAdminLog(this.getClass(), "doShipOrderedProduct", "START");
			if(orderedKey > 0){
				adminSvc.shipOrderedProduct(orderedKey);
			}			
			logger.debug("\n\t *********************** --> ID = "+orderedKey);
			ctrAdminLog(this.getClass(), "doShipOrderedProduct", "END");
		}
		
  //Generic Logger for this class
    private void ctrAdminLog(Class<? extends AdminOrder> paramCclass, String paramMethod, String paramMsg) {
  		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
  	}
}
