package org.nurture.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/t")
public class I18nCtrl {

	Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	
	@RequestMapping("/home")
	public String loadHome(){
		logger.info("******** Rendering Dashboard ....");
		return "dashBoard";
	}
}
