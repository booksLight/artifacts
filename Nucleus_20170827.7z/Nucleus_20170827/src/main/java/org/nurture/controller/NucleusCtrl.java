package org.nurture.controller;

import java.util.ArrayList;
import java.util.List;

import org.nurture.manager.entity.OutReach;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class NucleusCtrl {

	
	public  void welcome(){
		System.out.println(" ** in NucleusCtrl ...welcome()");
	
	}
	
	@RequestMapping("/rest")
	public  List<OutReach>  getOutReachData(){
		System.out.println(" ** in NucleusCtrl ...getOutReachData()");
		return getOutReaches();
	}

	
	private List<OutReach> getOutReaches() {
		List<OutReach> datas = new ArrayList<OutReach>();
		OutReach or = new OutReach(22,"Rest Template");
		datas.add(or);
		
		OutReach or1 = new OutReach(50,"Rest OutReach");
		datas.add(or1);
		
		return datas;
	}
	
}
