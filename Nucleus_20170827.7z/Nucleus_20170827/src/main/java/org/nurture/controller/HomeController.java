package org.nurture.controller;

import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.ModelUser;
import org.nurture.manager.util.Constants;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
public class HomeController {
 
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
		  
	  @Autowired
	  NurtureManager manager;
	 
    @RequestMapping("/")
    public String getHome(Model model, HttpServletRequest paramRequest) {
    	ctrLog(this.getClass(), "getHome", "START");
    	 String state = "dash/home";
    	 
    	ModelBarVo modelBarVo = manager.getUserModel(paramRequest);
    	  model.addAttribute("model",modelBarVo);
    	 
    	 ctrLog(this.getClass(), "getHome", "END ->"+state);
    		
    	return state;
    }

  
    @RequestMapping("/about")
    public String getAbout(Model model, HttpServletRequest paramRequest) {
    	ctrLog(this.getClass(), "getAbout", "START");
    	  
    	 String state = "dash/about";
    		
    	 ModelBarVo modelBarVo = manager.getUserModel(paramRequest);
   	  	model.addAttribute("model",modelBarVo);
   	  	
    	 ctrLog(this.getClass(), "getAbout", "END ->"+state);
    		
    	return state;
    }


	@RequestMapping("/login")
    public String getLogin(@RequestParam(value = "error", required=false) String error,
                        @RequestParam(value = "logout", required = false) String paramLogout, Model paramModel, HttpServletRequest paramRequest) {
		
		ctrLog(this.getClass(), "getLogin", "START");
		 URL url = manager.getReferral(paramRequest);
	        if(url != null){
	        	paramModel.addAttribute("referer", url.getPath());
	        }
	       
    	String state = "dash/flows/login";
    	paramModel.addAttribute("isLogin",true);
    	paramModel.addAttribute("user",  new ModelUser());
		paramModel.addAttribute("model", manager.getModel(paramRequest));
    	 
        if (error != null) {
        	paramModel.addAttribute("error", "Invalid username or password");
        }
        if (paramLogout != null) {
        	paramModel.addAttribute("msg", "You have been logged out successfully");
        }
        ctrLog(this.getClass(), "getLogin", "END ->"+state);
        return state;
    }
    
  
    @RequestMapping(value = "/security_check", method = RequestMethod.POST)
    public String getSecurityCheck(@Valid @ModelAttribute("user") ModelUser activeUser,
            BindingResult result, Model model, HttpServletRequest paramRequest) {
    	
    	ctrLog(this.getClass(), "getSecurityCheck", "START with Active User ="+activeUser.toString());
    	String state = "redirect:/";
    	 
    	 Customer customer = null;
    	UserVO userVO;
    	
    	ModelUser curentUser = getUser(activeUser); 
    	
    	if(curentUser==null){
    		return "redirect:/login";
    	}
    	
    	if(!activeUser.getPassword().equals(curentUser.getPassword())){
    		
    		return "redirect:/login";
    	}
    
    	ctrLog(this.getClass(), "getSecurityCheck", "User VALIDATION ***** = "+(activeUser.getPassword().equals(curentUser.getPassword())));
    
    	
    	  
    	ctrLog(this.getClass(), "getSecurityCheck", "User Details == "+curentUser.toString());
   
    
    	ModelBarVo modelUser = manager.getModel(paramRequest);
    	userVO = manager.getMapUserVO(curentUser);
    	userVO = manager.updateSession(userVO,paramRequest);
    	modelUser.setUserVo(userVO);
    		if(isNewCustomer(curentUser)){
    			modelUser.setCartEnable(false);
    		} else {
    			ctrLog(this.getClass(), "getSecurityCheck", "redirect:/customer/details");
          		 return "redirect:/customer/details";
    		}
    	
    	model.addAttribute(Constants.MODEL_USER,modelUser);
    	
    	ctrLog(this.getClass(), "getSecurityCheck", "User Details ->"+modelUser.toString());
    	ctrLog(this.getClass(), "getSecurityCheck", "END ->"+state);
    	 
    	 return state;
    }
    


	private boolean isNewCustomer(ModelUser curentUser) {
		Customer customer = manager.getCustomerByUserID((curentUser.getUserId()));
		boolean state = customer!=null ? true:false;
		return state;
	}





	private ModelUser getUser(ModelUser cuser) {
		if(cuser != null)
			return manager.getUserByMobile(cuser.getUsername());	
		return cuser;
	}

	@RequestMapping("/security_logout")
    public String getLogOut(String logout, Model model, HttpServletRequest paramRequest) {
		
		ctrLog(this.getClass(), "getLogOut", "START");
    	String state = "redirect:/";
    	
		 
    	 model.addAttribute("model", manager.getModel(paramRequest));
    	 manager.letMeLogOut(paramRequest);
    	 ctrLog(this.getClass(), "getLogOut", "END ->"+state);
    	 return state;    
    }
	
	
	 @RequestMapping("/contact")
	    public String geTcontactUs(HttpServletRequest paramRequest) {
	    	ctrLog(this.getClass(), "geTcontactUs", "START");
	    	 String state = "dash/contactus";
	    	 
	    	
	    	 ctrLog(this.getClass(), "geTcontactUs", "END ->"+state);
	    		
	    	return state;
	    }
	
	
	/* @RequestMapping("/social")
	    public String getSoclialHome(Model model, HttpServletRequest paramRequest) {
	    	ctrLog(this.getClass(), "getSoclialHome", "START");
	    	  
	    	 String state = "social";
	    	 
	    	 ModelVo tmpModel = manager.getUserModel(paramRequest);
	    	  model.addAttribute("model",tmpModel);
	    	 ctrLog(this.getClass(), "getSoclialHome", "END ->"+state);
	    		
	    	return state;
	    }*/

	 @RequestMapping("/test")
	    public String geTest(HttpServletRequest paramRequest) {
	    	ctrLog(this.getClass(), "geTest", "START");
	    	 String state = "test";
	    	 
	    	
	    	 ctrLog(this.getClass(), "geTest", "END ->"+state);
	    		
	    	return state;
	    }
	
	private void ctrLog(Class<? extends HomeController> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		
	}
   
}
