package org.nurture.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Cart;
import org.nurture.manager.entity.CartItem;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.Product;
import org.nurture.manager.util.CommonUtil;
import org.nurture.manager.vo.ModelBarVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;



@Controller
@RequestMapping("/rest/cart")
public class CartResources {

	private static final Logger logger = LoggerFactory.getLogger(CartResources.class);
	
	

    @Autowired
    NurtureManager manager;
    
    @RequestMapping("/{cartId}")
    public @ResponseBody Cart getCartById(@PathVariable(value = "cartId") int cartId) {
    	resLog(this.getClass(), "getCartById", "START " + cartId);
        return manager.getCartById(cartId);
    }

    //Request from OrderNow buton from product View
    @RequestMapping(value = "/add/{productId}", method = RequestMethod.GET) 
    public String addItem(@PathVariable(value = "productId") int productId, HttpServletRequest paramReq)  {
    	List<CartItem> cartItems = null;
    	Cart cart=null;
    	 Product product = null;
    	 CartItem cartItem = null;
    	resLog(this.getClass(), "addItem", "START " + productId);
    	 
    	resLog(this.getClass(), "addItem", "Product reteriveing if any.." + productId);
        product = manager.getProductById(productId);
        resLog(this.getClass(), "addItem", "Product found.." + productId);
        
        
        resLog(this.getClass(), "addItem", "Customer fetching .");
        ModelBarVo sessionUser = manager.getUserModel(paramReq);
        Integer lookupUserId = (sessionUser != null ? sessionUser.getUserVo() !=null ? sessionUser.getUserVo().getId():0:0);
        if(lookupUserId > 0){
        resLog(this.getClass(), "addItem", "Customer fetching based on User ID=" + lookupUserId);
        Customer customer = manager.getCustomerByUserID(lookupUserId);
        System.out.println("\n\n******** addItem **************** ");
        	new CommonUtil().renderCustomer(customer);
        
        resLog(this.getClass(), "addItem", "Cart reteriving from Customer fetched " + customer.getCustomerId());
        cart = customer.getCart();
        resLog(this.getClass(), "addItem", "Customer has cart =" + customer.getCart().getCartId());
        if(cart!= null){
        	  resLog(this.getClass(), "addItem", "fetching cartItems from the Cart " + cart.getCartId());
        	 cartItems = cart.getCartItems();
             resLog(this.getClass(), "addItem", "cartItems found.." + cartItems.toArray());
        }else{
        	 resLog(this.getClass(), "addItem", " Cart doesnot found for the  " + customer.getCustomerId());
        }
        
        
        
       
        
        for (int i = 0; i < cartItems.size(); i++) {
            if (product.getProductId() == cartItems.get(i).getProduct().getProductId()) {
                cartItem = cartItems.get(i);
                cartItem.setCartItemId(cartItem.getCartItemId());
                cartItem.setQuantity(cartItem.getQuantity() );
                cartItem.setTotalPrice(product.getProductPrice() * cartItem.getQuantity());
                cartItem.setProduct(product);
                manager.addCartItem(cartItem);
               
            }
        }
    
       cartItem = new CartItem();
      //cartItem.setCartItemId((ciid+1));
        cartItem.setProduct(product);
        cartItem.setQuantity(1);
        cartItem.setTotalPrice(product.getProductPrice() * cartItem.getQuantity());
        cartItem.setCart(cart);
        System.out.println("\n\n\t***** Item ready to add :"+cartItem);
       manager.addCartItem(cartItem);
      
        resLog(this.getClass(), "addItem", "END ");
        }else{
    	resLog(this.getClass(), "addItem", "No any Customer/user login... ");
        }
    	 return "redirect:/customer/cart";
    }

 

    @RequestMapping(value = "/remove/{cartItemId}", method = RequestMethod.GET)
    public String removeItem (@PathVariable(value = "cartItemId") int cartItemId) {
    	resLog(this.getClass(), "removeItem", "START " + cartItemId);
        manager.removeCartItemById(cartItemId);
        resLog(this.getClass(), "removeItem", "END="+cartItemId);
        return "redirect:/customer/cart";
    }
   
    @RequestMapping(value = "/{cartId}", method = RequestMethod.DELETE)
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void clearCart (@PathVariable(value = "cartId") int cartId) {
        Cart cart = manager.getCartById(cartId);
        manager.removeAllCartItems(cart);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Illegal request, please verify your payload.")
    public void handleClientErrors (Exception e) {}

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Internal server error")
    public void handleServerErrors (Exception e) {}

    
    
    
    //Generic Logger for this class
    private void resLog(Class<? extends CartResources> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
	}
}
