package org.nurture.controller;

import java.net.URL;

import javax.servlet.http.HttpServletRequest;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.vo.ModelBarVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;

@RequestMapping("/model")
@RestController
public class DashBoardController {

	private static Logger logger = LoggerFactory.getLogger(DashBoardController.class);

	@Autowired
	NurtureManager manager;

	@GetMapping("/info")
	protected ModelBarVo getModelBarInfo(HttpServletRequest paramRequest) {
		ctrLog(this.getClass(), "getModelBarInfo()", "/info");
		return manager.getUserModel(paramRequest);
	}

	@GetMapping("/referral")
	protected URL traceReferral(HttpServletRequest paramRequest) {
		ctrLog(this.getClass(), "traceReferral", "/referral");
		URL url =  manager.getReferral(paramRequest);		
		return url !=null ? url : null;
	}

	

	 @PostMapping("/mailUs")
	 public String mailUs(@RequestBody String data,  HttpServletRequest paramRequest) {
	    	ctrLog(this.getClass(), "Rest POST : mailUs", "START");
	    	 String state = "Your comments submitted successfully.";
	    	 
	    	logger.info("\n\t Feedbak =" +data.toString());
	    	 ctrLog(this.getClass(), "RestPOST :mailUs", "END ->"+state);
	    		
	    	return state;
	    }
	 
	 
	 public void ctrLog(Class<? extends DashBoardController> paramCclass, String paramMethod, String paramMsg) {
			logger.info(paramCclass.getName() + " : " + paramMethod + "() : /model" + paramMsg);
		}
}
