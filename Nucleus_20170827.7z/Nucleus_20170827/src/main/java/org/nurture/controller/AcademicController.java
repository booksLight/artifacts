package org.nurture.controller;

import javax.servlet.http.HttpServletRequest;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.util.ProductEnum;
import org.nurture.manager.vo.ModelBarVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AcademicController {

	private static final Logger logger = LoggerFactory.getLogger(AcademicController.class);
	
	  
	  @Autowired
	  NurtureManager manager;
	 
  @RequestMapping("/academic/{offSet}")
  public String getAcademic(@PathVariable(value = "offSet") int offSet, Model model, HttpServletRequest paramRequest) {
  	ctrLog(this.getClass(), "getAcademic", "START");
  	 String state = "dash/academic";
  	 
  	ModelBarVo modelBarVo = manager.getUserModel(paramRequest);
  	  model.addAttribute("model",modelBarVo);
  	  model.addAttribute("products",manager.lookUptProducts(ProductEnum.ACADEMIC.getProductType(),ProductEnum.NOTAPPLICABLE.getProductType(), offSet, manager.initPaginition(offSet,ProductEnum.ACADEMIC.getProductType(),ProductEnum.NOTAPPLICABLE.getProductType())));
  	 ctrLog(this.getClass(), "getAcademic", "END ->"+state);
  		
  	return state;
  }
  
  

  
	private void ctrLog(Class<? extends AcademicController> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		
	}
}
