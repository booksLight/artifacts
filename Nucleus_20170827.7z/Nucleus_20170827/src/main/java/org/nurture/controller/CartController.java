package org.nurture.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Cart;
import org.nurture.manager.entity.CartItem;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.vo.CartItemsVO;
import org.nurture.manager.vo.ProductVO;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
@RequestMapping("/customer/cart")
public class CartController {

	private static final Logger logger = LoggerFactory.getLogger(CartController.class);
	
   
    
    @Autowired
    NurtureManager manager;
    
    @RequestMapping(method = RequestMethod.GET)
    public String getCart(HttpServletRequest paramRequest ) {
    	
    	ctrLog(this.getClass(), "getCart", "START");
    	 
    	String state = "redirect:/customer/cart/";
    	 if(!manager.isUserLoggedOn(paramRequest)){
    		 state = "redirect:/login";
    	 }
    		        
    	UserVO curentUser = (UserVO) paramRequest.getSession().getAttribute("suser");
    	if(curentUser!=null){
    		Customer customer = manager.getCustomerByUserID(curentUser.getId());
    		//Customer customer = null;
    		ctrLog(this.getClass(),"getCart", "Current User ="+curentUser.toString());
      
    		int cartId = customer.getCart().getCartId();
        	ctrLog(this.getClass(), "getCart", "END ");
        	state = state + cartId;
    	}else{
    		state = "redirect:/login";
    	}
    	return state;
    }

    @RequestMapping(value ="/{cartId}", method = RequestMethod.GET)
    public String getCartRedirect(@PathVariable(value = "cartId") int cartId, Model model,HttpServletRequest paramRequest) {
    	ctrLog(this.getClass(), "getCartRedirect", "START");
    	 
    	String state = "dash/customer/cart";
    	CartItemsVO civ = null;
    	ProductVO pvo = null;
    	Double cartGrandTotal = 0.0;
    	List<CartItemsVO> civs = null;
    	Integer cartSize = 0;
    	 if(!manager.isUserLoggedOn(paramRequest)){
    		 state = "redirect:/login";
    	 }
    	Cart cart= manager.getCartById(cartId);
    	//Cart cart= null;
    	if(cart != null){
    		int itmLength =0;
    		 civs = new ArrayList<CartItemsVO>();
    		 cartSize = cart.getCartItems().size();
    		 logger.info("\n ***** CartItem SIZE ="+cartSize);
    		for(CartItem item : cart.getCartItems()){
    			civ = new CartItemsVO();
    			civ.setCartId(cartId);
    			civ.setCartItemId(item.getCartItemId());
    			civ.setQuantity(item.getQuantity());
    			civ.setTotalPrice(item.getTotalPrice());
    			if(item.getProduct() != null){
    				 pvo = new ProductVO();
    				 pvo.setProductId(item.getProduct().getProductId());
    				 pvo.setProductName(item.getProduct().getProductName());
    				 pvo.setProductPrice(item.getProduct().getProductPrice());
    				 pvo.setProductStatus(item.getProduct().getProductStatus());
    				 pvo.setProductCategory(item.getProduct().getProductCategory());
    				 pvo.setProductCondition(item.getProduct().getProductCondition());
    				 pvo.setProductDescription(item.getProduct().getProductDescription());
    				 pvo.setProductManufacture(item.getProduct().getProductManufacture());
    				 cartGrandTotal += pvo.getProductPrice();
    				 civ.setProductVo(pvo);
    				 logger.info("\n ***** Item to Cart ="+itmLength);
    				 itmLength++;
    			}
    			civs.add(civ);
    		}
    		cart.setGrandTotal(cartGrandTotal);
    			//manager.updateGrandTotal(cart);
    	}
    	model.addAttribute("calGrandTotal", cartGrandTotal);
    	model.addAttribute("cartItems",civs);
        model.addAttribute("cartId", cartId);
        model.addAttribute("model", manager.getUserModel(paramRequest));
        ctrLog(this.getClass(), "getCartRedirect", "END");
        return state;
    }
    
    
    //Generic Logger for this class
    private void ctrLog(Class<? extends CartController> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
	}
}
