package org.nurture.controller;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Cart;
import org.nurture.manager.entity.CartItem;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.CustomerOrder;
import org.nurture.manager.entity.ModelUser;
import org.nurture.manager.entity.OrderBook;
import org.nurture.manager.entity.Product;
import org.nurture.manager.mapper.ProductMapper;
import org.nurture.manager.util.CallenderUtil;
import org.nurture.manager.util.Constants;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;


@RestController
@RequestMapping("/product")
public class ProductRestController {

	private static final Logger logger = LoggerFactory.getLogger(ProductRestController.class);
	
   @Autowired
    NurtureManager manager;
    
    @GetMapping(value = "/products/{offSet}", produces = "application/json")
    public List<ProductMapper> getProductList (@PathVariable(value = "offSet") int offSet, Model model, HttpServletRequest paramRequest) {
    	
    	ctrLog(this.getClass(), "getProductList", "START");    	
    	List<ProductMapper> products = manager.lookUptProducts("GEN","NA", offSet, manager.initPaginition(offSet,"GEN", "NA"));
        ctrLog(this.getClass(), "getProductList", "END SIZE ="+(products != null ? products.size() :"NA"));
        return products !=null ? products : new ArrayList<ProductMapper>() ;
    }

    @GetMapping(value = "/view/{productId}", produces = "application/json")
    public Product viewProduct(@PathVariable int productId, Model model, HttpServletRequest paramRequest) {
    	 
    	ctrLog(this.getClass(), "viewProduct", "START");
    	Product product = manager.getProductById(productId);
    	    	
        ctrLog(this.getClass(), "viewProduct", "END");
        return product != null ? product : new Product();
    }
    
   // Generic Logger for this class
    private void ctrLog(Class<? extends ProductRestController> paramCclass, String paramMethod, String paramMsg) {
  		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
  	}
}
