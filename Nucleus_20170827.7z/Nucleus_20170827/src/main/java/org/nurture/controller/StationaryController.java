package org.nurture.controller;

import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.ModelUser;
import org.nurture.manager.util.Constants;
import org.nurture.manager.util.ProductEnum;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
public class StationaryController {
 
	private static final Logger logger = LoggerFactory.getLogger(StationaryController.class);
	
		  
	  @Autowired
	  NurtureManager manager;
	 
    @RequestMapping("/stationary/{offSet}")
    public String getStationary(@PathVariable(value = "offSet") int offSet, Model model, HttpServletRequest paramRequest) {
    	ctrLog(this.getClass(), "getStationary", "START");
    	 String state = "dash/stationary";
    	 
    	ModelBarVo modelBarVo = manager.getUserModel(paramRequest);
    	  model.addAttribute("model",modelBarVo);
    	  model.addAttribute("products",manager.lookUptProducts(ProductEnum.STATIONARY.getProductType(),ProductEnum.NOTAPPLICABLE.getProductType(), offSet, manager.initPaginition(offSet,ProductEnum.STATIONARY.getProductType(),ProductEnum.NOTAPPLICABLE.getProductType())));
    	 ctrLog(this.getClass(), "getStationary", "END ->"+state);
    		
    	return state;
    }

  
	private void ctrLog(Class<? extends StationaryController> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		
	}
   
}
