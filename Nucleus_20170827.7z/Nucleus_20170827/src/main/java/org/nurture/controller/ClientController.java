package org.nurture.controller;

import java.net.URL;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.ModelUser;
import org.nurture.manager.util.Constants;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller
@RequestMapping("/vender")
public class ClientController {
 
	private static final Logger logger = LoggerFactory.getLogger(ClientController.class);
	
	  @Autowired
	 NurtureManager manager;
	  
	 // TO DO Pagination
    @GetMapping("/brillient/{offSet}")
    public String getBrilientHome(@PathVariable(value = "offSet") int offSet, Model model, HttpServletRequest paramRequest) {
    	ctrLog(this.getClass(), "getBrilientHome", "START with Ofset ="+offSet);
    	 String state = "dash/clients/brillient";
    	
    	 model.addAttribute("model", manager.getUserModel(paramRequest));
    	 model.addAttribute(Constants.MODEL_USER, manager.getModel(paramRequest));
    	 model.addAttribute("pages", manager.getTotalPages("REB","BPS"));
    	 
    	 model.addAttribute("products",manager.lookUptProducts("REB","BPS", offSet, manager.initPaginition(offSet,"REB","BPS")));
    	 ctrLog(this.getClass(), "getBrilientHome", "END ->"+state);
    	return state;
    }

   
	private void ctrLog(Class<? extends ClientController> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
		
	}
   
}
