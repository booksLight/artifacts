package org.nurture.controller;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Cart;
import org.nurture.manager.entity.CartItem;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.CustomerOrder;
import org.nurture.manager.entity.ModelUser;
import org.nurture.manager.entity.OrderBook;
import org.nurture.manager.util.CallenderUtil;
import org.nurture.manager.util.CommonUtil;
import org.nurture.manager.util.Constants;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller
public class OrderController {

	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);
	
       
    @Autowired
	NurtureManager manager;
    
    @RequestMapping("/order/{cartId}")
    public String createOrder(@PathVariable("cartId") int cartId,Model model, HttpServletRequest paramRequest) {
    	
    	logger.debug("\n ***** CustomerOrderService -->createOrder() = "+cartId);
    	 
    	 String state = "checkout?cartId=";
    	 
    	if(!manager.isUserLoggedOn(paramRequest)){
    		 state = "redirect:/login";
    	 }
    	getCustomerByCartId(cartId);
        
        logger.debug("\n ***** Returning to CustomerOrderService --> = "+state + cartId);
       // return state + cart;
        model.addAttribute("model", manager.getUserModel(paramRequest));

        model.addAttribute("order",getCustomerByCartId(cartId));
        return "redirect:/customer/details/verify";
        //return "redirect:/checkout/"+cartId;
        //return "collectCustomerInfo";
    }
    
   
    
   


	@RequestMapping("/checkout/{cartId}")
    public String checkoutOrder(@PathVariable("cartId") int cartId, Model model, HttpServletRequest paramRequest) {
		 
    	 cosLog(this.getClass(), "checkoutOrder", "START");
    	 cosLog(this.getClass(), "checkoutOrder", "Parameters = "+cartId);
    	 cosLog(this.getClass(), "checkoutOrder", "END");
    	 model.addAttribute("model", manager.getUserModel(paramRequest));

    	 model.addAttribute("order",getCustomerByCartId(cartId));
    	//return "customerDetails";
    	 return "redirect:/customer/details/verify";
    }
    	
    @RequestMapping("/order/shipping/{cartId}")
    public String shippingOrder(@PathVariable("cartId") int cartId, Model model, HttpServletRequest paramRequest) {
    	 
    	 cosLog(this.getClass(), "shippingOrder", "START");
    	 cosLog(this.getClass(), "shippingOrder", "Parameters = "+cartId);
    	 cosLog(this.getClass(), "shippingOrder", "END");
    	 model.addAttribute("order",getCustomerByCartId(cartId));
    	 model.addAttribute("model", manager.getUserModel(paramRequest));

    	return "collectShippingDetail";
    }
   
    
    @RequestMapping("/order/confirmation/{cartId}")
    public String confirmationOrder(@PathVariable("cartId") int cartId, Model model, HttpServletRequest paramRequest) {
    	 
    	cosLog(this.getClass(), "confirmationOrder", "START");
    	 cosLog(this.getClass(), "confirmationOrder", "Parameters = "+cartId);
    	 cosLog(this.getClass(), "confirmationOrder", "END");
    	 model.addAttribute("order",getCustomerByCartId(cartId));
    	 model.addAttribute("model", manager.getUserModel(paramRequest));
    	 model.addAttribute("cartId", cartId);
    	return "dash/flows/orderConfirmation";
    }
    
    
    @RequestMapping("/order/receipt/{cartId}")
    public String receiptOrder(@PathVariable("cartId") int cartId, Model model, HttpServletRequest paramRequest) {
    	
    	 
    	 cosLog(this.getClass(), "receiptOrder", "START");
    	 cosLog(this.getClass(), "receiptOrder", "Parameters = "+cartId);
    	 cosLog(this.getClass(), "receiptOrder", "END");
    	 
    	 CustomerOrder customerNewOrder =  getCustomerByCartId(cartId);
    	 customerNewOrder.setConfirmed(Constants.TRUE);
    	 customerNewOrder.setStatus("Received");
    	 customerNewOrder.setStamped(CallenderUtil.convertDateJavaToSqlTimestamp(new Date()));
    	 manager.addCustomerOrder(customerNewOrder);
    	 
    	 String ordDT = new SimpleDateFormat("yyMMdd").format(new Date());
    	    
    	    String orderNo = "BL-" + ordDT + String.valueOf(customerNewOrder.getCustomerOrderId());
    	    logger.debug("   \n\t *********\n ORDER NO TO CUSTOMER =" + orderNo);
    	    
 //Saving CartItems to OrderBook
    	 List<OrderBook> orderedItems = manager.mapOrderBookOnCustomerOrder(customerNewOrder);
    	 manager.saveOrUpdateOrderedItems(orderedItems);
    	 manager.deleteOrderedItemsFromCart(customerNewOrder);
    	 
    	
    	  try{
         	manager.mailOrderAcknowledgment(customerNewOrder.getCustomer().getCustomerEmail(), customerNewOrder.getCustomer().getCustomerName(), orderNo);
          }catch(Exception e){
        	  cosLog(this.getClass(), "receiptOrder", "ERROR -->"+e);
          	
          } 
    	 model.addAttribute("order",customerNewOrder);
    	 model.addAttribute("model", manager.getUserModel(paramRequest));
    	 model.addAttribute("cartId", cartId);
    	 model.addAttribute("ordReceiptNo", orderNo);
    	return "dash/flows/thankCustomer";
    }
    
    @RequestMapping({"/order/book/{customerOrderId}"})
    public String getOrderBook(@PathVariable("customerOrderId") Integer customerOrderId, Model model, HttpServletRequest paramRequest)
    {
      
      cosLog(getClass(), "getOrderBook", "START");
      cosLog(getClass(), "getOrderBook", "Parameters = " + customerOrderId);
      
      URL url = manager.getReferral(paramRequest);
      if(url != null){
    	  model.addAttribute("referer", url.getPath());
      }
      
      CustomerOrder orderBook = manager.getCustomerOrderById(customerOrderId);
      
      Integer cartId = Integer.valueOf(orderBook != null ?  orderBook.getCart() != null ? orderBook.getCart().getCartId() : 0:0);
      
      logger.debug("\n\n **************** CartId for customer is ="+cartId);
      
      logger.debug("\n\n **************** orderBook.getCart().getCartId() for customer is ="+ orderBook.getCart().getCartId());
      
      for(CartItem ordItem : orderBook.getCart().getCartItems() ){
    	  
    	  logger.debug("\n Cart Item are ="+ordItem.toString());
    	  logger.debug("\n");
    	  
      }
      logger.debug("\n\n ##++++++++++++++++++## ORDER STATUS : \n Confirmed ="+orderBook.isConfirmed() +"\n Shipped "+orderBook.isShipped()+"\n Delivered "+orderBook.isDelivered()+"\n Timestamp "+orderBook.getStamped() );
      if (cartId.intValue() < 1) {
        return "redirect:/customer/cart";
      }
      model.addAttribute("order", orderBook);
      model.addAttribute("customer", getCustomerByCartId(cartId.intValue()));
      model.addAttribute("model", manager.getUserModel(paramRequest));
      model.addAttribute("cartId", cartId);
      
      cosLog(getClass(), "getOrderBook", "END");
      return "dash/flows/orderReceipt";
    }
    
    
    
    @RequestMapping("/order/status")
    public String workFlowOrder() {
    	 
    	cosLog(this.getClass(), "workFlowOrder", "START");
    	 
    	return "/dash/flows/orderFlow";
    }
    
    private CustomerOrder getCustomerByCartId(int cartId) {
    	CustomerOrder customerOrder = new CustomerOrder();
    	logger.info("\n ***** CustomerOrderService -->getCartById() = "+cartId);
        Cart cart = manager.getCartById(cartId);
        cart.setGrandTotal(manager.calculateOrderTotalAmt(cart));    
        

        Customer customer = cart.getCustomer();
        customerOrder.setCustomer(customer);
        customerOrder.setBillingAddress(customer.getBillingAddress());
        customerOrder.setShippingAddress(customer.getShippingAddress());
        manager.calculateDiscountAmt(cart, customer);
        customerOrder.setCart(cart);
        customerOrder.setCoupon(customer.getCouponId());
        System.out.println("\n -------------------DISCOUNTED Rs.="+cart.getDiscountAmt());
        new CommonUtil().renderCustomer(customer);
        return customerOrder;
		
	}

    
    
    private void cosLog(Class<? extends OrderController> paramCclass, String paramMethod, String paramMsg) {
		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
	}
}
