package org.nurture.controller;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.Cart;
import org.nurture.manager.entity.CartItem;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.CustomerOrder;
import org.nurture.manager.entity.ModelUser;
import org.nurture.manager.entity.OrderBook;
import org.nurture.manager.entity.Product;
import org.nurture.manager.util.CallenderUtil;
import org.nurture.manager.util.Constants;
import org.nurture.manager.util.ProductEnum;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller
@RequestMapping("/product")
public class ProductController {

	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	
       
    @Autowired
    NurtureManager manager;
    
    @RequestMapping("/productList/{offSet}")
    public String getProducts (@PathVariable(value = "offSet") int offSet, Model model, HttpServletRequest paramRequest) {
    	 
    	String state = "dash/nature/productList";
    	ctrLog(this.getClass(), "getProducts", "START");
    	 model.addAttribute("model", manager.getUserModel(paramRequest));  
    	 model.addAttribute("products",manager.lookUptProducts(ProductEnum.GENERAL.getProductType(),ProductEnum.NOTAPPLICABLE.getProductType(), offSet, manager.initPaginition(offSet,ProductEnum.GENERAL.getProductType(),ProductEnum.NOTAPPLICABLE.getProductType())));
    	 model.addAttribute("pages", manager.getTotalPages("GEN","NA"));
        ctrLog(this.getClass(), "getProducts", "END-->"+state);
        return state;
    }

    @RequestMapping("/viewProduct/{productId}")
    public String viewProduct(@PathVariable int productId, Model model, HttpServletRequest paramRequest) {
    	
    	String state = "dash/nature/viewProduct";
    	ctrLog(this.getClass(), "viewProduct", "START ");
    	Product product = manager.getProductById(productId);
        model.addAttribute("product", product);
        URL url = manager.getReferral(paramRequest);
        if(url != null){
        	 model.addAttribute("referer", url.getPath());
        }
       
        ModelBarVo mv = manager.getUserModel(paramRequest);
        model.addAttribute("model", mv);
    	
        ctrLog(this.getClass(), "viewProduct", "END-->"+state);
        return state;
    }
    
    //Generic Logger for this class
    private void ctrLog(Class<? extends ProductController> paramCclass, String paramMethod, String paramMsg) {
  		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
  	}
}
