package org.nurture.controller;

import java.net.URL;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.nurture.manager.NurtureManager;
import org.nurture.manager.entity.BillingAddress;
import org.nurture.manager.entity.Customer;
import org.nurture.manager.entity.CustomerOrder;
import org.nurture.manager.entity.ModelUser;
import org.nurture.manager.entity.ShippingAddress;
import org.nurture.manager.util.Constants;
import org.nurture.manager.vo.CustomerVO;
import org.nurture.manager.vo.ModelBarVo;
import org.nurture.manager.vo.UserVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	Customer customerDet;
	
 
    @Autowired
    NurtureManager manager;
    
    @RequestMapping("/details")
    public String viewCustomer(Model model, HttpServletRequest paramRequest) {
    	 
    	String state = "dash/customer/customerDetails";
    	ctrLog(this.getClass(), "viewCustomer", "START");
    	customerDet = new Customer();
    	UserVO curentUser = (UserVO) paramRequest.getSession().getAttribute("suser");
    	if(curentUser!=null){
    		
    		customerDet.setUserId(curentUser.getId());
    		customerDet.setCustomerEmail(curentUser.getEmail());
    		customerDet.setCustomerName(curentUser.getName());
    		customerDet.setCustomerPhone(curentUser.getMobile() != null ? curentUser.getMobile() : null);
    		
    	}else{
    		state = "redirect:/login";
    	}
    									// manager.getCustomerByUserID(curentUser.getId())
        model.addAttribute("customer",  customerDet);
        model.addAttribute("model", manager.getUserModel(paramRequest));

    	ctrLog(this.getClass(), "viewCustomer", "END-->"+state);
        return state;
    }

    @RequestMapping(value = "/info", method = RequestMethod.POST)
    public String getCustomerInfo(@Valid @ModelAttribute("customer") Customer customer,
                                       BindingResult result, Model model, HttpServletRequest paramRequest) {
    	
    	ctrLog(this.getClass(), "getCustomerInfo", "START");
    	String state = "dash/customer/customerDetails";
    	
    	if(customer.getCustomerName()!=null && customer.getCustomerName().length() >4){
    		customerDet.setCustomerName(customer.getCustomerName() );
    	}
    
    	if(customer.getCustomerPhone().length() == 10){
    		customerDet.setCustomerPhone(customer.getCustomerPhone() );
    	}
      
        model.addAttribute("customer",  customerDet);
        
        manager.updateUserName(customerDet);
        
       
        ctrLog(this.getClass(), "getCustomerInfo", "END-->"+state);
        return state;
    }
    
   
    
    @RequestMapping(value = "/billing/address", method = RequestMethod.POST)
    public String getCustomerBillingAddress(@Valid @ModelAttribute("customer") Customer customer,
                                       BindingResult result, Model model, HttpServletRequest paramRequest) {
    	
    	ctrLog(this.getClass(), "getCustomerBillingAddress", "START");
    	String state = "dash/customer/customerDetails";
    	

    	logger.debug("\n*******\n\t CustomerService getCustomerBillingAddress CUSTOMER ");
    	
    	
    	BillingAddress billAddress = (customer != null ? customer.getBillingAddress() != null ? customer.getBillingAddress() :null:null);
    	logger.debug("\n*******\n\t CustomerService BillingAddress.");
      	
        customerDet.setBillingAddress(billAddress);
        model.addAttribute("customer",  customerDet);
      
        ctrLog(this.getClass(), "getCustomerBillingAddress", "END-->"+state);
        return state;
    }
    
    
    @RequestMapping(value = "/shipping/address", method = RequestMethod.POST)
    public String getCustomerShippingAddress(@Valid @ModelAttribute("customer") Customer customer,
                                       BindingResult result, Model model, HttpServletRequest paramRequest) {
    	
    	ctrLog(this.getClass(), "getCustomerShippingAddress", "START");
    	String state = "redirect:/";
    	
    	/*if (result.hasErrors()) {
    			state = "redirect:/customer/details";
            return state;
        }*/

    	
    	ShippingAddress shippingAddress = (customer != null ? customer.getShippingAddress() != null ? customer.getShippingAddress() :null:null);
    	
    	
    	customerDet.setShippingAddress(shippingAddress);
    	ctrLog(this.getClass(), "**** getCustomerShippingAddress", "Customer ID-->"+customerDet.getCustomerId());
        
    	model.addAttribute("customer",  customerDet);
    	customerDet.setEnabled(true);
    	manager.updateCustomer(customerDet);

        ctrLog(this.getClass(), "getCustomerShippingAddress", "END-->"+state);
        return state;
   
    }
    
    
    @RequestMapping({"/profile"})
    public String viewCustomerProfile(Model model, HttpServletRequest paramRequest)
    {
     
      String state = "dash/customer/customerProfile";
      ctrLog(getClass(), "viewCustomerProfile", "START");
      
      customerDet = new Customer();
      UserVO curentUser = (UserVO)paramRequest.getSession().getAttribute("suser");
      if (curentUser != null)
      {
        customerDet.setUserId(curentUser.getId());
        customerDet.setCustomerEmail(curentUser.getEmail());
        customerDet.setCustomerName(curentUser.getName());
        customerDet.setCustomerPhone(curentUser.getMobile() != null ? curentUser.getMobile() : null);
      }
      else
      {
        state = "redirect:/login";
      }
      Customer temCustomer = manager.getCustomerByUserID(curentUser.getId());
      int cartId = temCustomer.getCart() != null ? temCustomer.getCart().getCartId() : 0;
      
      ctrLog(getClass(), "viewCustomerProfile", " ^^^^^ fetching orders detail for the cartId = " + cartId);
      
      List<CustomerOrder> orders = manager.getCustomerOrdersByCartId(cartId);
     
      model.addAttribute("orders", orders);
      model.addAttribute("customer", customerDet);
      model.addAttribute("model", manager.getUserModel(paramRequest));
      
      ctrLog(getClass(), "viewCustomerProfile", "END-->" + state);
      return state;
    }
    

    
    //During Checkout veify Customer details
    @RequestMapping("/details/verify")
    public String verifyCustomer(Model model, HttpServletRequest paramRequest) {    	 
    	
    	CustomerVO customerVO;
    	String state = "dash/customer/shippingDetails";
    	ctrLog(this.getClass(), "verifyCustomer", "START");
    	
    	UserVO curentUser = (UserVO) paramRequest.getSession().getAttribute("suser");
    	//Adding cartId to Model oblject
    	ctrLog(this.getClass(), "verifyCustomer", "checking wether logged user or not ...");
    	if(curentUser!=null){
    		ctrLog(this.getClass(), "verifyCustomer", "Since user not null, reteriving Customer details based on logged user = "+curentUser.getId());
    		customerVO = manager.mapCustomerVO(curentUser.getId());
    		
    		 ctrLog(this.getClass(), "verifyCustomer", "Reterive cart post identified Customer ...");
    		 int cartId = customerVO.getCart().getCartId();
    		 ctrLog(this.getClass(), "verifyCustomer", "Customer cart found with id="+cartId);
    		 customerVO.setEnabled(true);
    		 customerVO.setAppliedCoupon(new Integer(0));;
    		 model.addAttribute("customer",  customerVO);
        	 model.addAttribute("cartId", cartId);
        	 ctrLog(this.getClass(), "Fetching Customer Coupons =", ""+customerVO.getMapCoupon().size());
        	
    	}else{
    		state = "redirect:/login";
    	}
    	
    	
      
        model.addAttribute("model", manager.getUserModel(paramRequest));

    	ctrLog(this.getClass(), "verifyCustomer", "END-->"+state);
        return state;
    }

    @RequestMapping(value = "/shipping/address/update", method = RequestMethod.POST)
    public String updateShippingAddress(@Valid @ModelAttribute("customer") CustomerVO customerVO,
                                       BindingResult result, Model model, HttpServletRequest paramRequest) {
    	
    	ctrLog(this.getClass(), "getCustomerShippingAddress", "START");
    	ctrLog(this.getClass(), "getCustomerShippingAddress", "CUSTOMER Apartment No = "+customerVO.getShippingAddress().getApartmentNumber());
    	String state = "redirect:/customer/details/verify";
    	
    	/*if (result.hasErrors()) {
    		state = "redirect:/customer/details";
            return state;
        }*/
    		
    	Customer existCustomer = manager.getCustomerByUser(paramRequest);
    	
    	if(existCustomer != null && customerVO != null){
    		ctrLog(this.getClass(), "**** updateShippingAddress", "Logged Customer ID-->"+existCustomer.getCustomerId());
    		
    		ShippingAddress updatedShipAdd = customerVO.getShippingAddress();
    		ShippingAddress currentShipAdd = existCustomer.getShippingAddress();
    		
    		currentShipAdd.setApartmentNumber(updatedShipAdd !=null ? updatedShipAdd.getApartmentNumber() : currentShipAdd.getApartmentNumber());
    		currentShipAdd.setStreetName(updatedShipAdd !=null  ? updatedShipAdd.getStreetName() : currentShipAdd.getApartmentNumber() );
    		currentShipAdd.setCity(updatedShipAdd !=null  ? updatedShipAdd.getCity() : currentShipAdd.getCity() );
    		currentShipAdd.setState(updatedShipAdd !=null  ? updatedShipAdd.getState() : currentShipAdd.getState() );
    		currentShipAdd.setZipCode(updatedShipAdd !=null  ? updatedShipAdd.getZipCode() : currentShipAdd.getZipCode() );
    		currentShipAdd.setCountry(updatedShipAdd !=null  ? updatedShipAdd.getCountry() : currentShipAdd.getCountry() );
    		
    		existCustomer.setShippingAddress(currentShipAdd);
    		
    		int cartId = existCustomer.getCart().getCartId();
        	model.addAttribute("cartId", cartId);
        
        	
        	boolean response = manager.updateShippingAddress(existCustomer);
        			
        		
        	
        	model.addAttribute("customer",  existCustomer);
        	ctrLog(this.getClass(), "getCustomerShippingAddress", "updateShippingAddress ==-->"+response);
        	
    	}else{
    		state = "redirect:/login";
    	}
    	
        ctrLog(this.getClass(), "getCustomerShippingAddress", "END-->"+state);
        return state;
   
    }
    
    @RequestMapping(value = "/offer/coupon", method = RequestMethod.POST)
    @ResponseBody
    public String updateCustomerAvailedOffer(@Valid @ModelAttribute("customer") CustomerVO customerVO,
                                       BindingResult result, Model model, HttpServletRequest paramRequest) {
    	
    	String state = "Applied Successfully";
    	ctrLog(this.getClass(), "updateCustomerAvailedOffer", "START ");
    	if(customerVO != null ){    		
    		ctrLog(this.getClass(), "updateCustomerAvailedOffer", "Selected Coupon ="+customerVO.getAppliedCoupon());
        	manager.appliedCustomerCoupon(customerVO);
    	}
    	
    	ctrLog(this.getClass(), "updateCustomerAvailedOffer", "END-->"+state);
        return customerVO.getAppliedCoupon()+" "+state;
    }
    
 
	//Generic Logger for this class
    private void ctrLog(Class<? extends CustomerController> paramCclass, String paramMethod, String paramMsg) {
  		logger.info(paramCclass.getName() + " : " + paramMethod + "() : " + paramMsg);
  	}
}
