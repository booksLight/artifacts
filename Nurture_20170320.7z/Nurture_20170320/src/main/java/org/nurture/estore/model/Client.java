package org.nurture.estore.model;

public class Client {

	
}
