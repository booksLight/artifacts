
$(document).ready(function() {
	

    
});
  

/*
{
	"Message": "Number of Post office(s) found: 4",
	"Status": "Success",
	"PostOffice": [{
		"Name": "Ghosi  (Jehanabad)",
		"Description": "",
		"BranchType": "Sub Post Office",
		"DeliveryStatus": "Delivery",
		"Taluk": "Ghoshi",
		"Circle": "Ghoshi",
		"District": "Jehanabad",
		"Division": "Gaya",
		"Region": "Patna HQ",
		"State": "Bihar",
		"Country": "India"
	},*/